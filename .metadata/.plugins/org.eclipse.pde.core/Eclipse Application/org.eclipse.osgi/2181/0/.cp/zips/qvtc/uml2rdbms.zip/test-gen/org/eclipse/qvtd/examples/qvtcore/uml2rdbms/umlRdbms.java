/*******************************************************************************
 * «codeGenHelper.getCopyright(' * ')»
 *
 * This code is 100% auto-generated
 * using: org.eclipse.qvtd.codegen.qvti.java.QVTiCodeGenerator
 *
 * Do not edit it.
 ********************************************************************************/

package org.eclipse.qvtd.examples.qvtcore.uml2rdbms;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.PropertyId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.library.collection.CollectionAsSetOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionIncludesOperation;
import org.eclipse.ocl.pivot.library.collection.OrderedCollectionFirstOperation;
import org.eclipse.ocl.pivot.library.string.StringConcatOperation;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.BagValue;
import org.eclipse.ocl.pivot.values.OrderedSetValue;
import org.eclipse.ocl.pivot.values.SetValue;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.Column;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.ForeignKey;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.Key;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.Schema;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.SimplerdbmsFactory;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.SimplerdbmsPackage;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simplerdbms.Table;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.Association;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.Attribute;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.Class;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.Classifier;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.Package;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.PrimitiveDataType;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.SimpleumlPackage;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.AssociationToForeignKey;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.AttributeToColumn;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.BooleanToBoolean;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.ClassToTable;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.FromAttribute;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.FromAttributeOwner;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.IntegerToNumber;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.NonLeafAttribute;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.PackageToSchema;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.PrimitiveToName;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.Simpleuml2rdbmsFactory;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.Simpleuml2rdbmsPackage;
import org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml2rdbms.StringToVarchar;
import org.eclipse.qvtd.runtime.evaluation.AbstractInvocation;
import org.eclipse.qvtd.runtime.evaluation.AbstractTransformer;
import org.eclipse.qvtd.runtime.evaluation.Connection;
import org.eclipse.qvtd.runtime.evaluation.InvalidEvaluationException;
import org.eclipse.qvtd.runtime.evaluation.InvocationConstructor;
import org.eclipse.qvtd.runtime.evaluation.TransformationExecutor;
import org.eclipse.qvtd.runtime.internal.evaluation.AbstractInvocationConstructor;

/**
 * The umlRdbms transformation:
 * <p>
 * Construct with an evaluator
 * <br>
 * Populate each input model with {@link addRootObjects(String,List)}
 * <br>
 * {@link run()}
 * <br>
 * Extract each output model with {@link getRootObjects(String)}
 */
@SuppressWarnings("unused")
public class umlRdbms extends AbstractTransformer
{
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd/examples/qvtcore/UML2RDBMS/1.0/SimpleRDBMS", null, SimplerdbmsPackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd/examples/qvtcore/UML2RDBMS/1.0/SimpleUMLtoRDBMS", null, Simpleuml2rdbmsPackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd/examples/qvtcore/UML2RDBMS/1.0/simpleUML", null, SimpleumlPackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Association = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("Association", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_AssociationToForeignKey = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("AssociationToForeignKey", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Attribute = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("Attribute", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_AttributeToColumn = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("AttributeToColumn", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_BooleanToBoolean = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("BooleanToBoolean", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Class = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("Class", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_ClassToTable = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("ClassToTable", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Classifier = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("Classifier", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Column = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS.getClassId("Column", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_ForeignKey = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS.getClassId("ForeignKey", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_FromAttribute = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("FromAttribute", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_FromAttributeOwner = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("FromAttributeOwner", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_IntegerToNumber = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("IntegerToNumber", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Key = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS.getClassId("Key", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_NonLeafAttribute = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("NonLeafAttribute", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Package = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("Package", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_PackageToSchema = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("PackageToSchema", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_PrimitiveDataType = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_simpleUML.getClassId("PrimitiveDataType", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_PrimitiveToName = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("PrimitiveToName", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Schema = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS.getClassId("Schema", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_StringToVarchar = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleUMLtoRDBMS.getClassId("StringToVarchar", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Table = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtcore_s_UML2RDBMS_s_1_0_s_SimpleRDBMS.getClassId("Table", 0);
	public static final /*@NonInvalid*/ @NonNull String STR_2 = "2";
	public static final /*@NonInvalid*/ @NonNull String STR_BOOLEAN = "BOOLEAN";
	public static final /*@NonInvalid*/ @NonNull String STR_Boolean = "Boolean";
	public static final /*@NonInvalid*/ @NonNull String STR_Integer = "Integer";
	public static final /*@NonInvalid*/ @NonNull String STR_NUMBER = "NUMBER";
	public static final /*@NonInvalid*/ @NonNull String STR_String = "String";
	public static final /*@NonInvalid*/ @NonNull String STR_VARCHAR = "VARCHAR";
	public static final /*@NonInvalid*/ @NonNull String STR__ = "_";
	public static final /*@NonInvalid*/ @NonNull String STR__pk = "_pk";
	public static final /*@NonInvalid*/ @NonNull String STR__tid = "_tid";
	public static final /*@NonInvalid*/ @NonNull String STR_base = "base";
	public static final /*@NonInvalid*/ @NonNull String STR_primary = "primary";
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId BAG_CLSSid_AttributeToColumn = TypeId.BAG.getSpecializedId(CLSSid_AttributeToColumn);
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId ORD_CLSSid_Column = TypeId.ORDERED_SET.getSpecializedId(CLSSid_Column);
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId ORD_CLSSid_ForeignKey = TypeId.ORDERED_SET.getSpecializedId(CLSSid_ForeignKey);
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId ORD_CLSSid_Key = TypeId.ORDERED_SET.getSpecializedId(CLSSid_Key);
	public static final /*@NonInvalid*/ @NonNull PropertyId PROPid_primitive = CLSSid_PrimitiveToName.getPropertyId("primitive");
	public static final /*@NonInvalid*/ @NonNull PropertyId PROPid_umlClass = CLSSid_ClassToTable.getPropertyId("umlClass");
	public static final /*@NonInvalid*/ @NonNull PropertyId PROPid_umlPackage = CLSSid_PackageToSchema.getPropertyId("umlPackage");
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId SET_CLSSid_AttributeToColumn = TypeId.SET.getSpecializedId(CLSSid_AttributeToColumn);
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId SET_CLSSid_FromAttribute = TypeId.SET.getSpecializedId(CLSSid_FromAttribute);

	/*
	 * Property-source to Property-target unnavigable navigation caches
	 */
	protected final @NonNull Map<Class,ClassToTable> OPPOSITE_OF_ClassToTable_umlClass = new HashMap<Class,ClassToTable>();
	protected final @NonNull Map<Package,PackageToSchema> OPPOSITE_OF_PackageToSchema_umlPackage = new HashMap<Package,PackageToSchema>();
	protected final @NonNull Map<PrimitiveDataType,PrimitiveToName> OPPOSITE_OF_PrimitiveToName_primitive = new HashMap<PrimitiveDataType,PrimitiveToName>();

	/*
	 * Array of the source PropertyIds of each Property for which unnavigable opposite property navigation may occur.
	 */
	private static final @NonNull PropertyId @NonNull [] oppositeIndex2propertyId = new @NonNull PropertyId[]{
		PROPid_umlPackage,		// 0 => umlPackage
		PROPid_umlClass,		// 1 => umlClass
		PROPid_primitive		// 2 => primitive
	};

	/*
	 * Array of the ClassIds of each class for which allInstances() may be invoked. Array index is the ClassIndex.
	 */
	private static final @NonNull ClassId @NonNull [] classIndex2classId = new @NonNull ClassId[]{
		CLSSid_Association,                   // 0 => Association
		CLSSid_Attribute,                     // 1 => Attribute
		CLSSid_Class,                         // 2 => Class
		CLSSid_Package,                       // 3 => Package
		CLSSid_PrimitiveDataType              // 4 => PrimitiveDataType
	};

	/*
	 * Mapping from each ClassIndex to all the ClassIndexes to which an object of the outer index
	 * may contribute results to an allInstances() invocation.
	 * Non trivial inner arrays arise when one ClassId is a derivation of another and so an
	 * instance of the derived classId contributes to derived and inherited ClassIndexes.
	 */
	private final static int @NonNull [] @NonNull [] classIndex2allClassIndexes = new int @NonNull [] @NonNull [] {
		{0},                          // 0 : Association -> {Association}
		{1},                          // 1 : Attribute -> {Attribute}
		{2},                          // 2 : Class -> {Class}
		{3},                          // 3 : Package -> {Package}
		{4}                           // 4 : PrimitiveDataType -> {PrimitiveDataType}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR___root__ = new AbstractInvocationConstructor(invocationManager, "__root__", false)
	{
		@Override
		public @NonNull MAP___root__ newInstance(@NonNull Object @NonNull [] values) {
			return new MAP___root__(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_AssociationToForeignKey_column_foreignKey_owner_re_p1 = new AbstractInvocationConstructor(invocationManager, "m_AssociationToForeignKey_column_foreignKey_owner_re_p1", false)
	{
		@Override
		public @NonNull MAP_m_AssociationToForeignKey_column_foreignKey_owner_re_p1 newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_AssociationToForeignKey_column_foreignKey_owner_re_p1(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_NonLeafAttribute_leafs_owner_p1 = new AbstractInvocationConstructor(invocationManager, "m_NonLeafAttribute_leafs_owner_p1", false)
	{
		@Override
		public @NonNull MAP_m_NonLeafAttribute_leafs_owner_p1 newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_NonLeafAttribute_leafs_owner_p1(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_AttributeToColumn_leafs_name_owner_type_p1 = new AbstractInvocationConstructor(invocationManager, "m_AttributeToColumn_leafs_name_owner_type_p1", false)
	{
		@Override
		public @NonNull MAP_m_AttributeToColumn_leafs_name_owner_type_p1 newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_AttributeToColumn_leafs_name_owner_type_p1(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_AttributeToColumn_column = new AbstractInvocationConstructor(invocationManager, "m_AttributeToColumn_column", false)
	{
		@Override
		public @NonNull MAP_m_AttributeToColumn_column newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_AttributeToColumn_column(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_AttributeToColumn__type = new AbstractInvocationConstructor(invocationManager, "m_AttributeToColumn__type", false)
	{
		@Override
		public @NonNull MAP_m_AttributeToColumn__type newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_AttributeToColumn__type(this, values);
		}
	};

	protected final @NonNull AbstractInvocationConstructor CTOR_m_NonLeafAttribute_leafs_name_owner_p1 = new AbstractInvocationConstructor(invocationManager, "m_NonLeafAttribute_leafs_name_owner_p1", false)
	{
		@Override
		public @NonNull MAP_m_NonLeafAttribute_leafs_name_owner_p1 newInstance(@NonNull Object @NonNull [] values) {
			return new MAP_m_NonLeafAttribute_leafs_name_owner_p1(this, values);
		}
	};


	public umlRdbms(final @NonNull TransformationExecutor executor) {
		super(executor, new @NonNull String[] {"uml", "rdbms", "middle", "$primitive$"}, oppositeIndex2propertyId, classIndex2classId, classIndex2allClassIndexes);
	}

	@Override
	public boolean run() {
		final @NonNull Connection ji_Association = models[0/*uml*/].getConnection(0/*simpleuml::Association*/);
		final @NonNull Connection ji_Attribute = models[0/*uml*/].getConnection(1/*simpleuml::Attribute*/);
		final @NonNull Connection ji_Class = models[0/*uml*/].getConnection(2/*simpleuml::Class*/);
		final @NonNull Connection ji_Package = models[0/*uml*/].getConnection(3/*simpleuml::Package*/);
		final @NonNull Connection ji_PrimitiveDataType = models[0/*uml*/].getConnection(4/*simpleuml::PrimitiveDataType*/);
		CTOR___root__.invoke(ji_Association, ji_Attribute, ji_Class, ji_Package, ji_PrimitiveDataType);
		return invocationManager.flush();
	}

	/**
	 *
	 * map __root__ in umlRdbms {
	 *
	 *   append ji_Association  : simpleuml::Association[1];
	 * append ji_Attribute  : simpleuml::Attribute[1];
	 * append ji_Class  : simpleuml::Class[1];
	 * append ji_Package  : simpleuml::Package[1];
	 * append ji_PrimitiveDataType  : simpleuml::PrimitiveDataType[1];
	 * ::jm_AssociationToForeignKey : simpleuml2rdbms::AssociationToForeignKey[1]::jm_AttributeToColumn : simpleuml2rdbms::AttributeToColumn[1]::jm_BooleanToBoolean : simpleuml2rdbms::BooleanToBoolean[1]::jm_ClassToTable : simpleuml2rdbms::ClassToTable[1]::jm_IntegerToNumber : simpleuml2rdbms::IntegerToNumber[1]::jm_NonLeafAttribute : simpleuml2rdbms::NonLeafAttribute[1]::jm_StringToVarchar : simpleuml2rdbms::StringToVarchar[1]::jo_Key : simplerdbms::Key[1]install m_PackageToSchema_name_schema_umlPackage_r0 {
	 * p consumes append ji_Package  : simpleuml::Package[1];
	 * ;
	 * }
	 *   install m_AssociationToForeignKey_association_name_p0 {
	 * a consumes append ji_Association  : simpleuml::Association[1];
	 * ;
	 * jm_AssociationToForeignKey appendsTo jm_AssociationToForeignKey;
	 * }
	 *   install m_BooleanToBoolean_name_primitive_typeName_p0 {
	 * jm_BooleanToBoolean appendsTo jm_BooleanToBoolean;
	 * prim consumes append ji_PrimitiveDataType  : simpleuml::PrimitiveDataType[1];
	 * ;
	 * }
	 *   install m_BooleanToBoolean_owner_p1 {
	 * p2n consumes ::jm_BooleanToBoolean : simpleuml2rdbms::BooleanToBoolean[1];
	 * }
	 *   install m_NonLeafAttribute_attribute_kind_name_p0 {
	 * a consumes append ji_Attribute  : simpleuml::Attribute[1];
	 * ;
	 * jm_NonLeafAttribute appendsTo jm_NonLeafAttribute;
	 * }
	 *   install m_AttributeToColumn_attribute_kind_name_p0 {
	 * a consumes append ji_Attribute  : simpleuml::Attribute[1];
	 * ;
	 * jm_AttributeToColumn appendsTo jm_AttributeToColumn;
	 * }
	 *   install m_ClassToTable_name_umlClass_p0 {
	 * c consumes append ji_Class  : simpleuml::Class[1];
	 * ;
	 * jm_ClassToTable appendsTo jm_ClassToTable;
	 * }
	 *   install m_ClassToTable_column_owner_primaryKey_table_p1 {
	 * c2t consumes ::jm_ClassToTable : simpleuml2rdbms::ClassToTable[1];
	 * jo_Key appendsTo jo_Key;
	 * }
	 *   install m_ClassToTable__schema_p2 {
	 * c2t consumes ::jm_ClassToTable : simpleuml2rdbms::ClassToTable[1];
	 * }
	 *   install m_NonLeafAttribute_attribute_kind_p0 {
	 * a consumes append ji_Attribute  : simpleuml::Attribute[1];
	 * ;
	 * jm_NonLeafAttribute appendsTo jm_NonLeafAttribute;
	 * }
	 *   install m_AttributeToColumn_attribute_kind_p0 {
	 * a consumes append ji_Attribute  : simpleuml::Attribute[1];
	 * ;
	 * jm_AttributeToColumn appendsTo jm_AttributeToColumn;
	 * }
	 *   install m_IntegerToNumber_name_primitive_typeName_p0 {
	 * jm_IntegerToNumber appendsTo jm_IntegerToNumber;
	 * prim consumes append ji_PrimitiveDataType  : simpleuml::PrimitiveDataType[1];
	 * ;
	 * }
	 *   install m_IntegerToNumber_owner_p1 {
	 * p2n consumes ::jm_IntegerToNumber : simpleuml2rdbms::IntegerToNumber[1];
	 * }
	 *   install m_StringToVarchar_name_primitive_typeName_p0 {
	 * jm_StringToVarchar appendsTo jm_StringToVarchar;
	 * prim consumes append ji_PrimitiveDataType  : simpleuml::PrimitiveDataType[1];
	 * ;
	 * }
	 *   install m_AttributeToColumn_leafs_owner_type_p1 {
	 * fa consumes ::jm_AttributeToColumn : simpleuml2rdbms::AttributeToColumn[1];
	 * }
	 *   install m_StringToVarchar_owner_p1 {
	 * p2n consumes ::jm_StringToVarchar : simpleuml2rdbms::StringToVarchar[1];
	 * }
	 *   install m_AssociationToForeignKey_column_foreignKey_owner_re_p1 {
	 * a2f consumes ::jm_AssociationToForeignKey : simpleuml2rdbms::AssociationToForeignKey[1];
	 * rk consumes ::jo_Key : simplerdbms::Key[1];
	 * }
	 *   install m_NonLeafAttribute_leafs_owner_p1 {
	 * fa consumes ::jm_NonLeafAttribute : simpleuml2rdbms::NonLeafAttribute[1];
	 * }
	 *   install m_AttributeToColumn_leafs_name_owner_type_p1 {
	 * fa consumes ::jm_AttributeToColumn : simpleuml2rdbms::AttributeToColumn[1];
	 * fao consumes ::jm_NonLeafAttribute : simpleuml2rdbms::NonLeafAttribute[1];
	 * }
	 *   install m_AttributeToColumn_column {
	 * a2c consumes ::jm_AttributeToColumn : simpleuml2rdbms::AttributeToColumn[1];
	 * }
	 *   install m_AttributeToColumn__type {
	 * a2c consumes ::jm_AttributeToColumn : simpleuml2rdbms::AttributeToColumn[1];
	 * }
	 *   install m_NonLeafAttribute_leafs_name_owner_p1 {
	 * fa consumes ::jm_NonLeafAttribute : simpleuml2rdbms::NonLeafAttribute[1];
	 * fao consumes ::jm_NonLeafAttribute : simpleuml2rdbms::NonLeafAttribute[1];
	 * }
	 */
	protected class MAP___root__ extends AbstractInvocation
	{
		protected final @NonNull Connection ji_Association;
		protected final @NonNull Connection ji_Attribute;
		protected final @NonNull Connection ji_Class;
		protected final @NonNull Connection ji_Package;
		protected final @NonNull Connection ji_PrimitiveDataType;

		public MAP___root__(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			ji_Association = (Connection)boundValues[0];
			ji_Attribute = (Connection)boundValues[1];
			ji_Class = (Connection)boundValues[2];
			ji_Package = (Connection)boundValues[3];
			ji_PrimitiveDataType = (Connection)boundValues[4];
		}

		@Override
		public boolean execute()  {
			// connection variables
			final @NonNull Connection jm_AssociationToForeignKey_1 = createConnection("jm_AssociationToForeignKey", CLSSid_AssociationToForeignKey, false);
			final @NonNull Connection jm_AttributeToColumn_3 = createConnection("jm_AttributeToColumn", CLSSid_AttributeToColumn, false);
			final @NonNull Connection jm_BooleanToBoolean_1 = createConnection("jm_BooleanToBoolean", CLSSid_BooleanToBoolean, false);
			final @NonNull Connection jm_ClassToTable_1 = createConnection("jm_ClassToTable", CLSSid_ClassToTable, false);
			final @NonNull Connection jm_IntegerToNumber_1 = createConnection("jm_IntegerToNumber", CLSSid_IntegerToNumber, false);
			final @NonNull Connection jm_NonLeafAttribute_3 = createConnection("jm_NonLeafAttribute", CLSSid_NonLeafAttribute, false);
			final @NonNull Connection jm_StringToVarchar_1 = createConnection("jm_StringToVarchar", CLSSid_StringToVarchar, false);
			final @NonNull Connection jo_Key_1 = createConnection("jo_Key", CLSSid_Key, false);
			// mapping statements
			for (org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Package p_0 : ji_Package.typedIterable(Package.class)) {
				MAP_m_PackageToSchema_name_schema_umlPackage_r0(p_0);
			}
			for (@NonNull Association a_4 : ji_Association.typedIterable(Association.class)) {
				MAP_m_AssociationToForeignKey_association_name_p0(a_4, jm_AssociationToForeignKey_1);
			}
			for (@NonNull PrimitiveDataType prim_2 : ji_PrimitiveDataType.typedIterable(PrimitiveDataType.class)) {
				MAP_m_BooleanToBoolean_name_primitive_typeName_p0(jm_BooleanToBoolean_1, prim_2);
			}
			for (@NonNull BooleanToBoolean p2n_2 : jm_BooleanToBoolean_1.typedIterable(BooleanToBoolean.class)) {
				MAP_m_BooleanToBoolean_owner_p1(p2n_2);
			}
			for (@NonNull Attribute a_5 : ji_Attribute.typedIterable(Attribute.class)) {
				MAP_m_NonLeafAttribute_attribute_kind_name_p0(a_5, jm_NonLeafAttribute_3);
			}
			for (@NonNull Attribute a_6 : ji_Attribute.typedIterable(Attribute.class)) {
				MAP_m_AttributeToColumn_attribute_kind_name_p0(a_6, jm_AttributeToColumn_3);
			}
			for (org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class c_0 : ji_Class.typedIterable(Class.class)) {
				MAP_m_ClassToTable_name_umlClass_p0(c_0, jm_ClassToTable_1);
			}
			for (@NonNull ClassToTable c2t_1 : jm_ClassToTable_1.typedIterable(ClassToTable.class)) {
				MAP_m_ClassToTable_column_owner_primaryKey_table_p1(c2t_1, jo_Key_1);
			}
			for (@NonNull ClassToTable c2t_2 : jm_ClassToTable_1.typedIterable(ClassToTable.class)) {
				MAP_m_ClassToTable__schema_p2(c2t_2);
			}
			for (@NonNull Attribute a_7 : ji_Attribute.typedIterable(Attribute.class)) {
				MAP_m_NonLeafAttribute_attribute_kind_p0(a_7, jm_NonLeafAttribute_3);
			}
			for (@NonNull Attribute a_8 : ji_Attribute.typedIterable(Attribute.class)) {
				MAP_m_AttributeToColumn_attribute_kind_p0(a_8, jm_AttributeToColumn_3);
			}
			for (@NonNull PrimitiveDataType prim_3 : ji_PrimitiveDataType.typedIterable(PrimitiveDataType.class)) {
				MAP_m_IntegerToNumber_name_primitive_typeName_p0(jm_IntegerToNumber_1, prim_3);
			}
			for (@NonNull IntegerToNumber p2n_3 : jm_IntegerToNumber_1.typedIterable(IntegerToNumber.class)) {
				MAP_m_IntegerToNumber_owner_p1(p2n_3);
			}
			for (@NonNull PrimitiveDataType prim_4 : ji_PrimitiveDataType.typedIterable(PrimitiveDataType.class)) {
				MAP_m_StringToVarchar_name_primitive_typeName_p0(jm_StringToVarchar_1, prim_4);
			}
			for (@NonNull AttributeToColumn fa_3 : jm_AttributeToColumn_3.typedIterable(AttributeToColumn.class)) {
				MAP_m_AttributeToColumn_leafs_owner_type_p1(fa_3);
			}
			for (@NonNull StringToVarchar p2n_4 : jm_StringToVarchar_1.typedIterable(StringToVarchar.class)) {
				MAP_m_StringToVarchar_owner_p1(p2n_4);
			}
			invocationManager.flush();
			CTOR_m_AssociationToForeignKey_column_foreignKey_owner_re_p1.addConsumedConnection(jm_AssociationToForeignKey_1);
			CTOR_m_AssociationToForeignKey_column_foreignKey_owner_re_p1.addConsumedConnection(jo_Key_1);
			invocationManager.flush();
			invocationManager.flush();
			CTOR_m_NonLeafAttribute_leafs_owner_p1.addConsumedConnection(jm_NonLeafAttribute_3);
			invocationManager.flush();
			invocationManager.flush();
			CTOR_m_AttributeToColumn_leafs_name_owner_type_p1.addConsumedConnection(jm_AttributeToColumn_3);
			CTOR_m_AttributeToColumn_leafs_name_owner_type_p1.addConsumedConnection(jm_NonLeafAttribute_3);
			invocationManager.flush();
			invocationManager.flush();
			CTOR_m_AttributeToColumn_column.addConsumedConnection(jm_AttributeToColumn_3);
			invocationManager.flush();
			invocationManager.flush();
			CTOR_m_AttributeToColumn__type.addConsumedConnection(jm_AttributeToColumn_3);
			invocationManager.flush();
			invocationManager.flush();
			CTOR_m_NonLeafAttribute_leafs_name_owner_p1.addConsumedConnection(jm_NonLeafAttribute_3);
			CTOR_m_NonLeafAttribute_leafs_name_owner_p1.addConsumedConnection(jm_NonLeafAttribute_3);
			invocationManager.flush();
			final /*@Thrown*/ @Nullable Boolean __root__ = ValueUtil.TRUE_VALUE;
			return __root__;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(ji_Association, thoseValues[0])
				&& idResolver.oclEquals(ji_Attribute, thoseValues[1])
				&& idResolver.oclEquals(ji_Class, thoseValues[2])
				&& idResolver.oclEquals(ji_Package, thoseValues[3])
				&& idResolver.oclEquals(ji_PrimitiveDataType, thoseValues[4]);
		}
	}

	/**
	 *
	 * map m_PackageToSchema_name_schema_umlPackage_r0 in umlRdbms {
	 * guard:uml p  : simpleuml::Package[1];
	 * var name : String[?] := p.name;
	 * new:middle p2s : simpleuml2rdbms::PackageToSchema[1];
	 * new:rdbms s : simplerdbms::Schema[1];
	 * set p2s.schema := s;
	 * set p2s.umlPackage := p;
	 * set p2s.name := name;
	 * set s.name := name;
	 *
	 */
	protected boolean MAP_m_PackageToSchema_name_schema_umlPackage_r0(final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Package p)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_PackageToSchema_name_schema_umlPackage_r0" + ", " + p);
		}
		final /*@NonInvalid*/ @Nullable String name = p.getName();
		// creations
		final @SuppressWarnings("null")@NonNull PackageToSchema p2s = Simpleuml2rdbmsFactory.eINSTANCE.createPackageToSchema();
		models[2/*middle*/].add(p2s, false);
		final @SuppressWarnings("null")@NonNull Schema s = SimplerdbmsFactory.eINSTANCE.createSchema();
		models[1/*rdbms*/].add(s, false);
		// mapping statements
		p2s.setSchema(s);
		OPPOSITE_OF_PackageToSchema_umlPackage.put(p, p2s);
		p2s.setUmlPackage(p);
		p2s.setName(name);
		s.setName(name);
		final /*@Thrown*/ @Nullable Boolean m_PackageToSchema_name_schema_umlPackage_r0 = ValueUtil.TRUE_VALUE;
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((m_PackageToSchema_name_schema_umlPackage_r0 ? "done "  : "fail ") + "MAP_m_PackageToSchema_name_schema_umlPackage_r0");
		}
		return m_PackageToSchema_name_schema_umlPackage_r0;
	}

	/**
	 *
	 * map m_AssociationToForeignKey_association_name_p0 in umlRdbms {
	 * guard:uml a  : simpleuml::Association[1];
	 * append jm_AssociationToForeignKey  : simpleuml2rdbms::AssociationToForeignKey[1];
	 * var dc : simpleuml::Class[1] := a.destination;
	 * var p : simpleuml::Package[1] := a.namespace;
	 * var sc : simpleuml::Class[1] := a.source;
	 * check p =
	 *   sc.namespace;
	 * contained new:middle a2f : simpleuml2rdbms::AssociationToForeignKey[1];
	 * set a2f.association := a;
	 * set a2f.name := if dc = dc and sc = sc
	 *   then a.name
	 *   else
	 *     if dc <> dc and sc = sc
	 *     then dc.name + '_' + a.name
	 *     else
	 *       if dc = dc and sc <> sc
	 *       then a.name + '_' + sc.name
	 *       else dc.name + '_' + a.name + '_' + sc.name
	 *       endif
	 *     endif
	 *   endif;
	 * add jm_AssociationToForeignKey += a2f;
	 *
	 */
	protected boolean MAP_m_AssociationToForeignKey_association_name_p0(final /*@NonInvalid*/ @NonNull Association a, final @NonNull Connection jm_AssociationToForeignKey)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_AssociationToForeignKey_association_name_p0" + ", " + a + ", " + jm_AssociationToForeignKey);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class destination = a.getDestination();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = a.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class source = a.getSource();
			final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace_0 = source.getNamespace();
			final /*@Thrown*/ boolean symbol_1 = namespace.equals(namespace_0);
			/*@Thrown*/ @Nullable Boolean symbol_6;
			if (symbol_1) {
				// creations
				final @SuppressWarnings("null")@NonNull AssociationToForeignKey a2f_0 = Simpleuml2rdbmsFactory.eINSTANCE.createAssociationToForeignKey();
				models[2/*middle*/].add(a2f_0, true);
				// mapping statements
				a2f_0.setAssociation(a);
				final /*@NonInvalid*/ @Nullable String name = a.getName();
				a2f_0.setName(name);
				jm_AssociationToForeignKey.appendElement(a2f_0);
				final /*@Thrown*/ @Nullable Boolean m_AssociationToForeignKey_association_name_p0 = ValueUtil.TRUE_VALUE;
				symbol_6 = m_AssociationToForeignKey_association_name_p0;
			}
			else {
				symbol_6 = ValueUtil.FALSE_VALUE;
			}
			raw_p = symbol_6;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_AssociationToForeignKey_association_name_p0");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_BooleanToBoolean_name_primitive_typeName_p0 in umlRdbms {
	 * guard:uml prim  : simpleuml::PrimitiveDataType[1];
	 * append jm_BooleanToBoolean  : simpleuml2rdbms::BooleanToBoolean[1];
	 * var name : String[?] := prim.name;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * check name = 'Boolean';
	 * contained new:middle p2n : simpleuml2rdbms::BooleanToBoolean[1];
	 * set p2n.typeName := 'BOOLEAN';
	 * set p2n.primitive := prim;
	 * set p2n.name := name + '2' + 'BOOLEAN';
	 * add jm_BooleanToBoolean += p2n;
	 *
	 */
	protected boolean MAP_m_BooleanToBoolean_name_primitive_typeName_p0(final @NonNull Connection jm_BooleanToBoolean, final /*@NonInvalid*/ @NonNull PrimitiveDataType prim)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_BooleanToBoolean_name_primitive_typeName_p0" + ", " + jm_BooleanToBoolean + ", " + prim);
		}
		final /*@NonInvalid*/ @Nullable String name = prim.getName();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = prim.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@NonInvalid*/ boolean symbol_1 = STR_Boolean.equals(name);
			/*@Thrown*/ @Nullable Boolean symbol_7;
			if (symbol_1) {
				// creations
				final @SuppressWarnings("null")@NonNull BooleanToBoolean p2n_2 = Simpleuml2rdbmsFactory.eINSTANCE.createBooleanToBoolean();
				models[2/*middle*/].add(p2n_2, true);
				// mapping statements
				p2n_2.setTypeName(STR_BOOLEAN);
				OPPOSITE_OF_PrimitiveToName_primitive.put(prim, p2n_2);
				p2n_2.setPrimitive(prim);
				final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR_2);
				final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(sum, STR_BOOLEAN);
				p2n_2.setName(sum_0);
				jm_BooleanToBoolean.appendElement(p2n_2);
				final /*@Thrown*/ @Nullable Boolean m_BooleanToBoolean_name_primitive_typeName_p0 = ValueUtil.TRUE_VALUE;
				symbol_7 = m_BooleanToBoolean_name_primitive_typeName_p0;
			}
			else {
				symbol_7 = ValueUtil.FALSE_VALUE;
			}
			raw_p = symbol_7;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_BooleanToBoolean_name_primitive_typeName_p0");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_BooleanToBoolean_owner_p1 in umlRdbms {
	 * guard:middle p2n  : simpleuml2rdbms::BooleanToBoolean[1];
	 * var prim : simpleuml::PrimitiveDataType[1] := p2n.primitive;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := p.middle;
	 * set p2n.owner := p2s;
	 *
	 */
	protected boolean MAP_m_BooleanToBoolean_owner_p1(final /*@NonInvalid*/ @NonNull BooleanToBoolean p2n)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_BooleanToBoolean_owner_p1" + ", " + p2n);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull PrimitiveDataType primitive = p2n.getPrimitive();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = primitive.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@Thrown*/ @Nullable PackageToSchema middle = OPPOSITE_OF_PackageToSchema_umlPackage.get(namespace);
			final /*@Thrown*/ boolean symbol_1 = middle != null;
			/*@Thrown*/ @Nullable Boolean raw_p2s;
			if (symbol_1) {
				if (middle == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				// mapping statements
				p2n.setOwner(middle);
				final /*@Thrown*/ @Nullable Boolean m_BooleanToBoolean_owner_p1 = ValueUtil.TRUE_VALUE;
				raw_p2s = m_BooleanToBoolean_owner_p1;
			}
			else {
				raw_p2s = ValueUtil.FALSE_VALUE;
			}
			raw_p = raw_p2s;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_BooleanToBoolean_owner_p1");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_NonLeafAttribute_attribute_kind_name_p0 in umlRdbms {
	 * guard:uml a  : simpleuml::Attribute[1];
	 * append jm_NonLeafAttribute  : simpleuml2rdbms::NonLeafAttribute[1];
	 * var c : simpleuml::Class[1] := a.owner;
	 * var kind : String[?] := a.kind;
	 * var name : String[?] := a.name;
	 * check var t : simpleuml::Class[1] := a.type;
	 * contained new:middle fa : simpleuml2rdbms::NonLeafAttribute[1];
	 * set fa.attribute := a;
	 * set fa.kind := kind;
	 * notify set fa.name := name;
	 * add jm_NonLeafAttribute += fa;
	 *
	 */
	protected boolean MAP_m_NonLeafAttribute_attribute_kind_name_p0(final /*@NonInvalid*/ @NonNull Attribute a_0, final @NonNull Connection jm_NonLeafAttribute)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_NonLeafAttribute_attribute_kind_name_p0" + ", " + a_0 + ", " + jm_NonLeafAttribute);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = a_0.getOwner();
		final /*@NonInvalid*/ @Nullable String kind = a_0.getKind();
		final /*@NonInvalid*/ @Nullable String name = a_0.getName();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull Classifier temp1_t = a_0.getType();
		final /*@NonInvalid*/ boolean symbol_0 = temp1_t instanceof Class;
		/*@Thrown*/ @Nullable Boolean symbol_7;
		if (symbol_0) {
			final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class symbol_1 = (Class)temp1_t;
			// creations
			final @SuppressWarnings("null")@NonNull NonLeafAttribute fa_3 = Simpleuml2rdbmsFactory.eINSTANCE.createNonLeafAttribute();
			models[2/*middle*/].add(fa_3, true);
			// mapping statements
			fa_3.setAttribute(a_0);
			fa_3.setKind(kind);
			fa_3.setName(name);
			objectManager.assigned(fa_3, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, name, null);
			jm_NonLeafAttribute.appendElement(fa_3);
			final /*@Thrown*/ @Nullable Boolean m_NonLeafAttribute_attribute_kind_name_p0 = ValueUtil.TRUE_VALUE;
			symbol_7 = m_NonLeafAttribute_attribute_kind_name_p0;
		}
		else {
			symbol_7 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_7 ? "done "  : "fail ") + "MAP_m_NonLeafAttribute_attribute_kind_name_p0");
		}
		return symbol_7;
	}

	/**
	 *
	 * map m_AttributeToColumn_attribute_kind_name_p0 in umlRdbms {
	 * guard:uml a  : simpleuml::Attribute[1];
	 * append jm_AttributeToColumn  : simpleuml2rdbms::AttributeToColumn[1];
	 * var c : simpleuml::Class[1] := a.owner;
	 * var kind : String[?] := a.kind;
	 * var name : String[?] := a.name;
	 * check var t : simpleuml::PrimitiveDataType[1] := a.type;
	 * contained new:middle fa : simpleuml2rdbms::AttributeToColumn[1];
	 * set fa.attribute := a;
	 * set fa.kind := kind;
	 * notify set fa.name := name;
	 * add jm_AttributeToColumn += fa;
	 *
	 */
	protected boolean MAP_m_AttributeToColumn_attribute_kind_name_p0(final /*@NonInvalid*/ @NonNull Attribute a_1, final @NonNull Connection jm_AttributeToColumn)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_AttributeToColumn_attribute_kind_name_p0" + ", " + a_1 + ", " + jm_AttributeToColumn);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = a_1.getOwner();
		final /*@NonInvalid*/ @Nullable String kind = a_1.getKind();
		final /*@NonInvalid*/ @Nullable String name = a_1.getName();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull Classifier temp1_t = a_1.getType();
		final /*@NonInvalid*/ boolean symbol_0 = temp1_t instanceof PrimitiveDataType;
		/*@Thrown*/ @Nullable Boolean symbol_7;
		if (symbol_0) {
			final /*@NonInvalid*/ @NonNull PrimitiveDataType symbol_1 = (PrimitiveDataType)temp1_t;
			// creations
			final @SuppressWarnings("null")@NonNull AttributeToColumn fa_3 = Simpleuml2rdbmsFactory.eINSTANCE.createAttributeToColumn();
			models[2/*middle*/].add(fa_3, true);
			// mapping statements
			fa_3.setAttribute(a_1);
			fa_3.setKind(kind);
			fa_3.setName(name);
			objectManager.assigned(fa_3, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, name, null);
			jm_AttributeToColumn.appendElement(fa_3);
			final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn_attribute_kind_name_p0 = ValueUtil.TRUE_VALUE;
			symbol_7 = m_AttributeToColumn_attribute_kind_name_p0;
		}
		else {
			symbol_7 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_7 ? "done "  : "fail ") + "MAP_m_AttributeToColumn_attribute_kind_name_p0");
		}
		return symbol_7;
	}

	/**
	 *
	 * map m_ClassToTable_name_umlClass_p0 in umlRdbms {
	 * guard:uml c  : simpleuml::Class[1];
	 * append jm_ClassToTable  : simpleuml2rdbms::ClassToTable[1];
	 * var name : String[?] := c.name;
	 * var p : simpleuml::Package[1] := c.namespace;
	 * contained new:middle c2t : simpleuml2rdbms::ClassToTable[1];
	 * set c2t.umlClass := c;
	 * set c2t.name := name;
	 * add jm_ClassToTable += c2t;
	 *
	 */
	protected boolean MAP_m_ClassToTable_name_umlClass_p0(final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class c, final org.eclipse.qvtd.runtime.evaluation.@org.eclipse.jdt.annotation.NonNull Connection jm_ClassToTable)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_ClassToTable_name_umlClass_p0" + ", " + c + ", " + jm_ClassToTable);
		}
		final /*@NonInvalid*/ @Nullable String name = c.getName();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = c.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			// creations
			final @SuppressWarnings("null")@NonNull ClassToTable c2t_1 = Simpleuml2rdbmsFactory.eINSTANCE.createClassToTable();
			models[2/*middle*/].add(c2t_1, true);
			// mapping statements
			OPPOSITE_OF_ClassToTable_umlClass.put(c, c2t_1);
			c2t_1.setUmlClass(c);
			c2t_1.setName(name);
			jm_ClassToTable.appendElement(c2t_1);
			final /*@Thrown*/ @Nullable Boolean m_ClassToTable_name_umlClass_p0 = ValueUtil.TRUE_VALUE;
			raw_p = m_ClassToTable_name_umlClass_p0;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_ClassToTable_name_umlClass_p0");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_ClassToTable_column_owner_primaryKey_table_p1 in umlRdbms {
	 * guard:middle c2t  : simpleuml2rdbms::ClassToTable[1];
	 * append jo_Key  : simplerdbms::Key[1];
	 * var c : simpleuml::Class[1] := c2t.umlClass;
	 * var name : String[?] := c2t.name;
	 * var p : simpleuml::Package[1] := c.namespace;
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := p.middle;
	 * check name =
	 *   c.name;
	 * contained new:rdbms pc : simplerdbms::Column[1];
	 * contained new:rdbms pk : simplerdbms::Key[1];
	 * contained new:rdbms t : simplerdbms::Table[1];
	 * notify set pc.type := 'NUMBER';
	 * set pk.kind := 'primary';
	 * set t.kind := 'base';
	 * set pc.keys := OrderedSet{pk
	 *   };
	 * notify set pc.owner := t;
	 * set c2t.column := pc;
	 * set c2t.primaryKey := pk;
	 * set c2t.table := t;
	 * set pk.owner := t;
	 * set t.name := name;
	 * set pc.name := name + '_tid';
	 * set pk.name := name + '_pk';
	 * set c2t.owner := p2s;
	 * add jo_Key += pk;
	 *
	 */
	protected boolean MAP_m_ClassToTable_column_owner_primaryKey_table_p1(final /*@NonInvalid*/ @NonNull ClassToTable c2t, final @NonNull Connection jo_Key)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_ClassToTable_column_owner_primaryKey_table_p1" + ", " + c2t + ", " + jo_Key);
		}
		final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Class umlClass = c2t.getUmlClass();
		final /*@NonInvalid*/ boolean symbol_0 = umlClass != null;
		/*@Thrown*/ @Nullable Boolean raw_c;
		if (symbol_0) {
			if (umlClass == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@NonInvalid*/ @Nullable String name = c2t.getName();
			final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = umlClass.getNamespace();
			final /*@Thrown*/ boolean symbol_1 = namespace != null;
			/*@Thrown*/ @Nullable Boolean raw_p;
			if (symbol_1) {
				if (namespace == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				final /*@Thrown*/ @Nullable PackageToSchema middle = OPPOSITE_OF_PackageToSchema_umlPackage.get(namespace);
				final /*@Thrown*/ boolean symbol_2 = middle != null;
				/*@Thrown*/ @Nullable Boolean raw_p2s;
				if (symbol_2) {
					if (middle == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					final /*@Thrown*/ @Nullable String name_0 = umlClass.getName();
					final /*@Thrown*/ boolean symbol_3 = (name != null) ? name.equals(name_0) : (name_0 == null);
					/*@Thrown*/ @Nullable Boolean symbol_19;
					if (symbol_3) {
						// creations
						final @SuppressWarnings("null")@NonNull Column pc = SimplerdbmsFactory.eINSTANCE.createColumn();
						models[1/*rdbms*/].add(pc, true);
						final @SuppressWarnings("null")@NonNull Key pk = SimplerdbmsFactory.eINSTANCE.createKey();
						models[1/*rdbms*/].add(pk, true);
						final @SuppressWarnings("null")@NonNull Table t = SimplerdbmsFactory.eINSTANCE.createTable();
						models[1/*rdbms*/].add(t, true);
						// mapping statements
						pc.setType(STR_NUMBER);
						objectManager.assigned(pc, SimplerdbmsPackage.Literals.COLUMN__TYPE, STR_NUMBER, null);
						pk.setKind(STR_primary);
						t.setKind(STR_base);
						final /*@Thrown*/ @NonNull OrderedSetValue OrderedSet = ValueUtil.createOrderedSetOfEach(ORD_CLSSid_Key, pk);
						final /*@Thrown*/ @NonNull List<Key> ECORE_OrderedSet = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(Key.class, OrderedSet);
						pc.getKeys().addAll(ECORE_OrderedSet);
						pc.setOwner(t);
						objectManager.assigned(pc, SimplerdbmsPackage.Literals.COLUMN__OWNER, t, null);
						c2t.setColumn(pc);
						c2t.setPrimaryKey(pk);
						c2t.setTable(t);
						pk.setOwner(t);
						t.setName(name);
						final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR__tid);
						pc.setName(sum);
						final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(name, STR__pk);
						pk.setName(sum_0);
						c2t.setOwner(middle);
						jo_Key.appendElement(pk);
						final /*@Thrown*/ @Nullable Boolean m_ClassToTable_column_owner_primaryKey_table_p1 = ValueUtil.TRUE_VALUE;
						symbol_19 = m_ClassToTable_column_owner_primaryKey_table_p1;
					}
					else {
						symbol_19 = ValueUtil.FALSE_VALUE;
					}
					raw_p2s = symbol_19;
				}
				else {
					raw_p2s = ValueUtil.FALSE_VALUE;
				}
				raw_p = raw_p2s;
			}
			else {
				raw_p = ValueUtil.FALSE_VALUE;
			}
			raw_c = raw_p;
		}
		else {
			raw_c = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_c ? "done "  : "fail ") + "MAP_m_ClassToTable_column_owner_primaryKey_table_p1");
		}
		return raw_c;
	}

	/**
	 *
	 * map m_ClassToTable__schema_p2 in umlRdbms {
	 * guard:middle c2t  : simpleuml2rdbms::ClassToTable[1];
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := c2t.owner;
	 * var t : simplerdbms::Table[1] := c2t.table;
	 * var s : simplerdbms::Schema[1] := p2s.schema;
	 * set t.schema := s;
	 *
	 */
	protected boolean MAP_m_ClassToTable__schema_p2(final /*@NonInvalid*/ @NonNull ClassToTable c2t_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_ClassToTable__schema_p2" + ", " + c2t_0);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull PackageToSchema owner = c2t_0.getOwner();
		final /*@NonInvalid*/ @Nullable Table table = c2t_0.getTable();
		final /*@NonInvalid*/ boolean symbol_0 = table != null;
		/*@Thrown*/ @Nullable Boolean raw_t;
		if (symbol_0) {
			if (table == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@NonInvalid*/ @NonNull Schema schema = owner.getSchema();
			// mapping statements
			table.setSchema(schema);
			final /*@Thrown*/ @Nullable Boolean m_ClassToTable__schema_p2 = ValueUtil.TRUE_VALUE;
			raw_t = m_ClassToTable__schema_p2;
		}
		else {
			raw_t = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_t ? "done "  : "fail ") + "MAP_m_ClassToTable__schema_p2");
		}
		return raw_t;
	}

	/**
	 *
	 * map m_NonLeafAttribute_attribute_kind_p0 in umlRdbms {
	 * guard:uml a  : simpleuml::Attribute[1];
	 * append jm_NonLeafAttribute  : simpleuml2rdbms::NonLeafAttribute[1];
	 * var c : simpleuml::Class[1] := a.owner;
	 * var kind : String[?] := a.kind;
	 * var name : String[?] := a.name;
	 * check var t : simpleuml::Class[1] := a.type;
	 * contained new:middle fa : simpleuml2rdbms::NonLeafAttribute[1];
	 * set fa.attribute := a;
	 * set fa.kind := kind;
	 * add jm_NonLeafAttribute += fa;
	 *
	 */
	protected boolean MAP_m_NonLeafAttribute_attribute_kind_p0(final /*@NonInvalid*/ @NonNull Attribute a_2, final @NonNull Connection jm_NonLeafAttribute_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_NonLeafAttribute_attribute_kind_p0" + ", " + a_2 + ", " + jm_NonLeafAttribute_0);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = a_2.getOwner();
		final /*@NonInvalid*/ @Nullable String kind = a_2.getKind();
		final /*@NonInvalid*/ @Nullable String name = a_2.getName();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull Classifier temp1_t = a_2.getType();
		final /*@NonInvalid*/ boolean symbol_0 = temp1_t instanceof Class;
		/*@Thrown*/ @Nullable Boolean symbol_6;
		if (symbol_0) {
			final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class symbol_1 = (Class)temp1_t;
			// creations
			final @SuppressWarnings("null")@NonNull NonLeafAttribute fa_3 = Simpleuml2rdbmsFactory.eINSTANCE.createNonLeafAttribute();
			models[2/*middle*/].add(fa_3, true);
			// mapping statements
			fa_3.setAttribute(a_2);
			fa_3.setKind(kind);
			jm_NonLeafAttribute_0.appendElement(fa_3);
			final /*@Thrown*/ @Nullable Boolean m_NonLeafAttribute_attribute_kind_p0 = ValueUtil.TRUE_VALUE;
			symbol_6 = m_NonLeafAttribute_attribute_kind_p0;
		}
		else {
			symbol_6 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_6 ? "done "  : "fail ") + "MAP_m_NonLeafAttribute_attribute_kind_p0");
		}
		return symbol_6;
	}

	/**
	 *
	 * map m_AttributeToColumn_attribute_kind_p0 in umlRdbms {
	 * guard:uml a  : simpleuml::Attribute[1];
	 * append jm_AttributeToColumn  : simpleuml2rdbms::AttributeToColumn[1];
	 * var c : simpleuml::Class[1] := a.owner;
	 * var kind : String[?] := a.kind;
	 * var name : String[?] := a.name;
	 * check var t : simpleuml::PrimitiveDataType[1] := a.type;
	 * contained new:middle fa : simpleuml2rdbms::AttributeToColumn[1];
	 * set fa.attribute := a;
	 * set fa.kind := kind;
	 * add jm_AttributeToColumn += fa;
	 *
	 */
	protected boolean MAP_m_AttributeToColumn_attribute_kind_p0(final /*@NonInvalid*/ @NonNull Attribute a_3, final @NonNull Connection jm_AttributeToColumn_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_AttributeToColumn_attribute_kind_p0" + ", " + a_3 + ", " + jm_AttributeToColumn_0);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = a_3.getOwner();
		final /*@NonInvalid*/ @Nullable String kind = a_3.getKind();
		final /*@NonInvalid*/ @Nullable String name = a_3.getName();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull Classifier temp1_t = a_3.getType();
		final /*@NonInvalid*/ boolean symbol_0 = temp1_t instanceof PrimitiveDataType;
		/*@Thrown*/ @Nullable Boolean symbol_6;
		if (symbol_0) {
			final /*@NonInvalid*/ @NonNull PrimitiveDataType symbol_1 = (PrimitiveDataType)temp1_t;
			// creations
			final @SuppressWarnings("null")@NonNull AttributeToColumn fa_3 = Simpleuml2rdbmsFactory.eINSTANCE.createAttributeToColumn();
			models[2/*middle*/].add(fa_3, true);
			// mapping statements
			fa_3.setAttribute(a_3);
			fa_3.setKind(kind);
			jm_AttributeToColumn_0.appendElement(fa_3);
			final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn_attribute_kind_p0 = ValueUtil.TRUE_VALUE;
			symbol_6 = m_AttributeToColumn_attribute_kind_p0;
		}
		else {
			symbol_6 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_6 ? "done "  : "fail ") + "MAP_m_AttributeToColumn_attribute_kind_p0");
		}
		return symbol_6;
	}

	/**
	 *
	 * map m_IntegerToNumber_name_primitive_typeName_p0 in umlRdbms {
	 * guard:uml prim  : simpleuml::PrimitiveDataType[1];
	 * append jm_IntegerToNumber  : simpleuml2rdbms::IntegerToNumber[1];
	 * var name : String[?] := prim.name;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * check name = 'Integer';
	 * contained new:middle p2n : simpleuml2rdbms::IntegerToNumber[1];
	 * set p2n.typeName := 'NUMBER';
	 * set p2n.primitive := prim;
	 * set p2n.name := name + '2' + 'NUMBER';
	 * add jm_IntegerToNumber += p2n;
	 *
	 */
	protected boolean MAP_m_IntegerToNumber_name_primitive_typeName_p0(final @NonNull Connection jm_IntegerToNumber, final /*@NonInvalid*/ @NonNull PrimitiveDataType prim_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_IntegerToNumber_name_primitive_typeName_p0" + ", " + jm_IntegerToNumber + ", " + prim_0);
		}
		final /*@NonInvalid*/ @Nullable String name = prim_0.getName();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = prim_0.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@NonInvalid*/ boolean symbol_1 = STR_Integer.equals(name);
			/*@Thrown*/ @Nullable Boolean symbol_7;
			if (symbol_1) {
				// creations
				final @SuppressWarnings("null")@NonNull IntegerToNumber p2n_2 = Simpleuml2rdbmsFactory.eINSTANCE.createIntegerToNumber();
				models[2/*middle*/].add(p2n_2, true);
				// mapping statements
				p2n_2.setTypeName(STR_NUMBER);
				OPPOSITE_OF_PrimitiveToName_primitive.put(prim_0, p2n_2);
				p2n_2.setPrimitive(prim_0);
				final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR_2);
				final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(sum, STR_NUMBER);
				p2n_2.setName(sum_0);
				jm_IntegerToNumber.appendElement(p2n_2);
				final /*@Thrown*/ @Nullable Boolean m_IntegerToNumber_name_primitive_typeName_p0 = ValueUtil.TRUE_VALUE;
				symbol_7 = m_IntegerToNumber_name_primitive_typeName_p0;
			}
			else {
				symbol_7 = ValueUtil.FALSE_VALUE;
			}
			raw_p = symbol_7;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_IntegerToNumber_name_primitive_typeName_p0");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_IntegerToNumber_owner_p1 in umlRdbms {
	 * guard:middle p2n  : simpleuml2rdbms::IntegerToNumber[1];
	 * var prim : simpleuml::PrimitiveDataType[1] := p2n.primitive;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := p.middle;
	 * set p2n.owner := p2s;
	 *
	 */
	protected boolean MAP_m_IntegerToNumber_owner_p1(final /*@NonInvalid*/ @NonNull IntegerToNumber p2n_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_IntegerToNumber_owner_p1" + ", " + p2n_0);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull PrimitiveDataType primitive = p2n_0.getPrimitive();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = primitive.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@Thrown*/ @Nullable PackageToSchema middle = OPPOSITE_OF_PackageToSchema_umlPackage.get(namespace);
			final /*@Thrown*/ boolean symbol_1 = middle != null;
			/*@Thrown*/ @Nullable Boolean raw_p2s;
			if (symbol_1) {
				if (middle == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				// mapping statements
				p2n_0.setOwner(middle);
				final /*@Thrown*/ @Nullable Boolean m_IntegerToNumber_owner_p1 = ValueUtil.TRUE_VALUE;
				raw_p2s = m_IntegerToNumber_owner_p1;
			}
			else {
				raw_p2s = ValueUtil.FALSE_VALUE;
			}
			raw_p = raw_p2s;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_IntegerToNumber_owner_p1");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_StringToVarchar_name_primitive_typeName_p0 in umlRdbms {
	 * guard:uml prim  : simpleuml::PrimitiveDataType[1];
	 * append jm_StringToVarchar  : simpleuml2rdbms::StringToVarchar[1];
	 * var name : String[?] := prim.name;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * check name = 'String';
	 * contained new:middle p2n : simpleuml2rdbms::StringToVarchar[1];
	 * set p2n.typeName := 'VARCHAR';
	 * set p2n.primitive := prim;
	 * set p2n.name := name + '2' + 'VARCHAR';
	 * add jm_StringToVarchar += p2n;
	 *
	 */
	protected boolean MAP_m_StringToVarchar_name_primitive_typeName_p0(final @NonNull Connection jm_StringToVarchar, final /*@NonInvalid*/ @NonNull PrimitiveDataType prim_1)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_StringToVarchar_name_primitive_typeName_p0" + ", " + jm_StringToVarchar + ", " + prim_1);
		}
		final /*@NonInvalid*/ @Nullable String name = prim_1.getName();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = prim_1.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@NonInvalid*/ boolean symbol_1 = STR_String.equals(name);
			/*@Thrown*/ @Nullable Boolean symbol_7;
			if (symbol_1) {
				// creations
				final @SuppressWarnings("null")@NonNull StringToVarchar p2n_2 = Simpleuml2rdbmsFactory.eINSTANCE.createStringToVarchar();
				models[2/*middle*/].add(p2n_2, true);
				// mapping statements
				p2n_2.setTypeName(STR_VARCHAR);
				OPPOSITE_OF_PrimitiveToName_primitive.put(prim_1, p2n_2);
				p2n_2.setPrimitive(prim_1);
				final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR_2);
				final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(sum, STR_VARCHAR);
				p2n_2.setName(sum_0);
				jm_StringToVarchar.appendElement(p2n_2);
				final /*@Thrown*/ @Nullable Boolean m_StringToVarchar_name_primitive_typeName_p0 = ValueUtil.TRUE_VALUE;
				symbol_7 = m_StringToVarchar_name_primitive_typeName_p0;
			}
			else {
				symbol_7 = ValueUtil.FALSE_VALUE;
			}
			raw_p = symbol_7;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_StringToVarchar_name_primitive_typeName_p0");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_AttributeToColumn_leafs_owner_type_p1 in umlRdbms {
	 *
	 *   guard:middle fa  : simpleuml2rdbms::AttributeToColumn[1];
	 * var a : simpleuml::Attribute[1] := fa.attribute;
	 * var c : simpleuml::Class[1] := a.owner;
	 * check var t : simpleuml::PrimitiveDataType[1] := a.type;
	 * var fao : simpleuml2rdbms::ClassToTable[1] := c.middle;
	 * var p2n : simpleuml2rdbms::PrimitiveToName[1] := t.middle;
	 * notify set fa.leafs := Set{fa
	 *   };
	 * set fa.owner := fao;
	 * notify set fa.type := p2n;
	 *
	 */
	protected boolean MAP_m_AttributeToColumn_leafs_owner_type_p1(final /*@NonInvalid*/ @NonNull AttributeToColumn fa)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_AttributeToColumn_leafs_owner_type_p1" + ", " + fa);
		}
		final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ @Nullable Attribute attribute = fa.getAttribute();
		final /*@NonInvalid*/ boolean symbol_0 = attribute != null;
		/*@Thrown*/ @Nullable Boolean raw_a;
		if (symbol_0) {
			if (attribute == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = attribute.getOwner();
			@SuppressWarnings("null")
			final /*@Thrown*/ @NonNull Classifier temp1_t = attribute.getType();
			final /*@NonInvalid*/ boolean symbol_1 = temp1_t instanceof PrimitiveDataType;
			/*@Thrown*/ @Nullable Boolean symbol_9;
			if (symbol_1) {
				final /*@Thrown*/ @NonNull PrimitiveDataType symbol_2 = (PrimitiveDataType)temp1_t;
				final /*@Thrown*/ @Nullable ClassToTable middle = OPPOSITE_OF_ClassToTable_umlClass.get(owner);
				final /*@Thrown*/ boolean symbol_3 = middle != null;
				/*@Thrown*/ @Nullable Boolean raw_fao;
				if (symbol_3) {
					if (middle == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					final /*@Thrown*/ @Nullable PrimitiveToName middle_0 = OPPOSITE_OF_PrimitiveToName_primitive.get(symbol_2);
					final /*@Thrown*/ boolean symbol_4 = middle_0 != null;
					/*@Thrown*/ @Nullable Boolean raw_p2n;
					if (symbol_4) {
						if (middle_0 == null) {
							throw new InvalidEvaluationException("Null where non-null value required");
						}
						// mapping statements
						final /*@NonInvalid*/ @NonNull SetValue Set = ValueUtil.createSetOfEach(SET_CLSSid_AttributeToColumn, fa);
						final /*@NonInvalid*/ @NonNull List<AttributeToColumn> ECORE_Set = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(AttributeToColumn.class, Set);
						fa.getLeafs().addAll(ECORE_Set);
						objectManager.assigned(fa, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, ECORE_Set, null);
						fa.setOwner(middle);
						fa.setType(middle_0);
						objectManager.assigned(fa, Simpleuml2rdbmsPackage.Literals.ATTRIBUTE_TO_COLUMN__TYPE, middle_0, null);
						final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn_leafs_owner_type_p1 = ValueUtil.TRUE_VALUE;
						raw_p2n = m_AttributeToColumn_leafs_owner_type_p1;
					}
					else {
						raw_p2n = ValueUtil.FALSE_VALUE;
					}
					raw_fao = raw_p2n;
				}
				else {
					raw_fao = ValueUtil.FALSE_VALUE;
				}
				symbol_9 = raw_fao;
			}
			else {
				symbol_9 = ValueUtil.FALSE_VALUE;
			}
			raw_a = symbol_9;
		}
		else {
			raw_a = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_a ? "done "  : "fail ") + "MAP_m_AttributeToColumn_leafs_owner_type_p1");
		}
		return raw_a;
	}

	/**
	 *
	 * map m_StringToVarchar_owner_p1 in umlRdbms {
	 * guard:middle p2n  : simpleuml2rdbms::StringToVarchar[1];
	 * var prim : simpleuml::PrimitiveDataType[1] := p2n.primitive;
	 * var p : simpleuml::Package[1] := prim.namespace;
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := p.middle;
	 * set p2n.owner := p2s;
	 *
	 */
	protected boolean MAP_m_StringToVarchar_owner_p1(final /*@NonInvalid*/ @NonNull StringToVarchar p2n_1)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_StringToVarchar_owner_p1" + ", " + p2n_1);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull PrimitiveDataType primitive = p2n_1.getPrimitive();
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = primitive.getNamespace();
		final /*@NonInvalid*/ boolean symbol_0 = namespace != null;
		/*@Thrown*/ @Nullable Boolean raw_p;
		if (symbol_0) {
			if (namespace == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@Thrown*/ @Nullable PackageToSchema middle = OPPOSITE_OF_PackageToSchema_umlPackage.get(namespace);
			final /*@Thrown*/ boolean symbol_1 = middle != null;
			/*@Thrown*/ @Nullable Boolean raw_p2s;
			if (symbol_1) {
				if (middle == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				// mapping statements
				p2n_1.setOwner(middle);
				final /*@Thrown*/ @Nullable Boolean m_StringToVarchar_owner_p1 = ValueUtil.TRUE_VALUE;
				raw_p2s = m_StringToVarchar_owner_p1;
			}
			else {
				raw_p2s = ValueUtil.FALSE_VALUE;
			}
			raw_p = raw_p2s;
		}
		else {
			raw_p = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_p ? "done "  : "fail ") + "MAP_m_StringToVarchar_owner_p1");
		}
		return raw_p;
	}

	/**
	 *
	 * map m_AssociationToForeignKey_column_foreignKey_owner_re_p1 in umlRdbms {
	 *
	 *   guard:middle a2f  : simpleuml2rdbms::AssociationToForeignKey[1];
	 * guard:rdbms rk  : simplerdbms::Key[1];
	 * var a : simpleuml::Association[1] := a2f.association;
	 * var column : OrderedSet(simplerdbms::Column) := rk.column;
	 * var dt : simplerdbms::Table[1] := rk.owner;
	 * var _'if' : String[?] := a2f.name;
	 * var kind : String[?] := rk.kind;
	 * var dc : simpleuml::Class[1] := a.destination;
	 * var first : simplerdbms::Column[1] := column->first();
	 * var p : simpleuml::Package[1] := a.namespace;
	 * var sc : simpleuml::Class[1] := a.source;
	 * check kind = 'primary';
	 * var dc2t : simpleuml2rdbms::ClassToTable[1] := dc.middle;
	 * var p2s : simpleuml2rdbms::PackageToSchema[1] := p.middle;
	 * var sc2t : simpleuml2rdbms::ClassToTable[1] := sc.middle;
	 * var type : String[?] := first.type;
	 * var s : simplerdbms::Schema[1] := p2s.schema;
	 * var st : simplerdbms::Table[1] := sc2t.table;
	 * check p = sc.namespace;
	 * check type = first.type;
	 * check p2s = sc2t.owner;
	 * check dt = dc2t.table;
	 * check s =
	 *   st.schema;
	 * contained new:rdbms fc : simplerdbms::Column[1];
	 * contained new:rdbms fk : simplerdbms::ForeignKey[1];
	 * set fc.foreignKeys := OrderedSet{fk
	 *   };
	 * set fk.refersTo := rk;
	 * set a2f.column := fc;
	 * set a2f.foreignKey := fk;
	 * set fk.name := _'if';
	 * set fc.name := _'if' + '_tid';
	 * notify set fc.type := type;
	 * set a2f.owner := sc2t;
	 * set a2f.referenced := dc2t;
	 * notify set fc.owner := st;
	 * set fk.owner := st;
	 *
	 */
	protected class MAP_m_AssociationToForeignKey_column_foreignKey_owner_re_p1 extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull AssociationToForeignKey a2f;
		protected final /*@NonInvalid*/ @NonNull Key rk;

		public MAP_m_AssociationToForeignKey_column_foreignKey_owner_re_p1(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			a2f = (AssociationToForeignKey)boundValues[0];
			rk = (Key)boundValues[1];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ @Nullable Association association = a2f.getAssociation();
			final /*@NonInvalid*/ boolean symbol_0 = association != null;
			/*@Thrown*/ @Nullable Boolean raw_a;
			if (symbol_0) {
				if (association == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				@SuppressWarnings("null")
				final /*@NonInvalid*/ @NonNull List<Column> column = rk.getColumn();
				@SuppressWarnings("null")
				final /*@NonInvalid*/ @NonNull Table owner = rk.getOwner();
				final /*@NonInvalid*/ @Nullable String name = a2f.getName();
				final /*@NonInvalid*/ @Nullable String kind = rk.getKind();
				@SuppressWarnings("null")
				final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class destination = association.getDestination();
				final /*@NonInvalid*/ @NonNull OrderedSetValue BOXED_column = idResolver.createOrderedSetOfAll(ORD_CLSSid_Column, column);
				final /*@Thrown*/ @Nullable Column first = (Column)OrderedCollectionFirstOperation.INSTANCE.evaluate(BOXED_column);
				if (first == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace = association.getNamespace();
				final /*@Thrown*/ boolean symbol_1 = namespace != null;
				/*@Thrown*/ @Nullable Boolean raw_p;
				if (symbol_1) {
					if (namespace == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					@SuppressWarnings("null")
					final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class source = association.getSource();
					final /*@NonInvalid*/ boolean symbol_2 = STR_primary.equals(kind);
					/*@Thrown*/ @Nullable Boolean symbol_27;
					if (symbol_2) {
						final /*@Thrown*/ @Nullable ClassToTable middle = OPPOSITE_OF_ClassToTable_umlClass.get(destination);
						final /*@Thrown*/ boolean symbol_3 = middle != null;
						/*@Thrown*/ @Nullable Boolean raw_dc2t;
						if (symbol_3) {
							if (middle == null) {
								throw new InvalidEvaluationException("Null where non-null value required");
							}
							final /*@Thrown*/ @Nullable PackageToSchema middle_0 = OPPOSITE_OF_PackageToSchema_umlPackage.get(namespace);
							final /*@Thrown*/ boolean symbol_4 = middle_0 != null;
							/*@Thrown*/ @Nullable Boolean raw_p2s;
							if (symbol_4) {
								if (middle_0 == null) {
									throw new InvalidEvaluationException("Null where non-null value required");
								}
								final /*@Thrown*/ @Nullable ClassToTable middle_1 = OPPOSITE_OF_ClassToTable_umlClass.get(source);
								final /*@Thrown*/ boolean symbol_5 = middle_1 != null;
								/*@Thrown*/ @Nullable Boolean raw_sc2t;
								if (symbol_5) {
									if (middle_1 == null) {
										throw new InvalidEvaluationException("Null where non-null value required");
									}
									objectManager.getting(first, SimplerdbmsPackage.Literals.COLUMN__TYPE, false);
									final /*@Thrown*/ @Nullable String type = first.getType();
									@SuppressWarnings("null")
									final /*@Thrown*/ @NonNull Schema schema = middle_0.getSchema();
									final /*@Thrown*/ @Nullable Table table = middle_1.getTable();
									final /*@Thrown*/ boolean symbol_6 = table != null;
									/*@Thrown*/ @Nullable Boolean raw_st;
									if (symbol_6) {
										if (table == null) {
											throw new InvalidEvaluationException("Null where non-null value required");
										}
										final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@Nullable Package namespace_0 = source.getNamespace();
										final /*@Thrown*/ boolean symbol_7 = namespace.equals(namespace_0);
										/*@Thrown*/ @Nullable Boolean symbol_26;
										if (symbol_7) {
											@SuppressWarnings("null")
											final /*@Thrown*/ @NonNull PackageToSchema owner_0 = middle_1.getOwner();
											final /*@Thrown*/ boolean symbol_8 = middle_0.equals(owner_0);
											/*@Thrown*/ @Nullable Boolean symbol_25;
											if (symbol_8) {
												final /*@Thrown*/ @Nullable Table table_0 = middle.getTable();
												final /*@Thrown*/ boolean symbol_9 = owner.equals(table_0);
												/*@Thrown*/ @Nullable Boolean symbol_24;
												if (symbol_9) {
													@SuppressWarnings("null")
													final /*@Thrown*/ @NonNull Schema schema_0 = table.getSchema();
													final /*@Thrown*/ boolean symbol_10 = schema.equals(schema_0);
													/*@Thrown*/ @Nullable Boolean symbol_23;
													if (symbol_10) {
														// creations
														final @SuppressWarnings("null")@NonNull Column fc = SimplerdbmsFactory.eINSTANCE.createColumn();
														models[1/*rdbms*/].add(fc, true);
														final @SuppressWarnings("null")@NonNull ForeignKey fk = SimplerdbmsFactory.eINSTANCE.createForeignKey();
														models[1/*rdbms*/].add(fk, true);
														// mapping statements
														final /*@Thrown*/ @NonNull OrderedSetValue OrderedSet = ValueUtil.createOrderedSetOfEach(ORD_CLSSid_ForeignKey, fk);
														final /*@Thrown*/ @NonNull List<ForeignKey> ECORE_OrderedSet = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(ForeignKey.class, OrderedSet);
														fc.getForeignKeys().addAll(ECORE_OrderedSet);
														fk.setRefersTo(rk);
														a2f.setColumn(fc);
														a2f.setForeignKey(fk);
														fk.setName(name);
														final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR__tid);
														fc.setName(sum);
														fc.setType(type);
														objectManager.assigned(fc, SimplerdbmsPackage.Literals.COLUMN__TYPE, type, null);
														a2f.setOwner(middle_1);
														a2f.setReferenced(middle);
														fc.setOwner(table);
														objectManager.assigned(fc, SimplerdbmsPackage.Literals.COLUMN__OWNER, table, null);
														fk.setOwner(table);
														final /*@Thrown*/ @Nullable Boolean m_AssociationToForeignKey_column_foreignKey_owner_re_p1 = ValueUtil.TRUE_VALUE;
														symbol_23 = m_AssociationToForeignKey_column_foreignKey_owner_re_p1;
													}
													else {
														symbol_23 = ValueUtil.FALSE_VALUE;
													}
													symbol_24 = symbol_23;
												}
												else {
													symbol_24 = ValueUtil.FALSE_VALUE;
												}
												symbol_25 = symbol_24;
											}
											else {
												symbol_25 = ValueUtil.FALSE_VALUE;
											}
											symbol_26 = symbol_25;
										}
										else {
											symbol_26 = ValueUtil.FALSE_VALUE;
										}
										raw_st = symbol_26;
									}
									else {
										raw_st = ValueUtil.FALSE_VALUE;
									}
									raw_sc2t = raw_st;
								}
								else {
									raw_sc2t = ValueUtil.FALSE_VALUE;
								}
								raw_p2s = raw_sc2t;
							}
							else {
								raw_p2s = ValueUtil.FALSE_VALUE;
							}
							raw_dc2t = raw_p2s;
						}
						else {
							raw_dc2t = ValueUtil.FALSE_VALUE;
						}
						symbol_27 = raw_dc2t;
					}
					else {
						symbol_27 = ValueUtil.FALSE_VALUE;
					}
					raw_p = symbol_27;
				}
				else {
					raw_p = ValueUtil.FALSE_VALUE;
				}
				raw_a = raw_p;
			}
			else {
				raw_a = ValueUtil.FALSE_VALUE;
			}
			return raw_a;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(a2f, thoseValues[0])
				&& idResolver.oclEquals(rk, thoseValues[1]);
		}
	}

	/**
	 *
	 * map m_NonLeafAttribute_leafs_owner_p1 in umlRdbms {
	 *
	 *   guard:middle fa  : simpleuml2rdbms::NonLeafAttribute[1];
	 * var a : simpleuml::Attribute[1] := fa.attribute;
	 * var c : simpleuml::Class[1] := a.owner;
	 * var fao : simpleuml2rdbms::ClassToTable[1] := c.middle;
	 * var fromAttributes : Set(simpleuml2rdbms::FromAttribute) := fao.fromAttributes;
	 * set fa.owner := fao;
	 * notify set fa.leafs := fromAttributes->collect(_'1_' | _'1_'.leafs)
	 *   ->asSet();
	 *
	 */
	protected class MAP_m_NonLeafAttribute_leafs_owner_p1 extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull NonLeafAttribute fa_0;

		public MAP_m_NonLeafAttribute_leafs_owner_p1(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			fa_0 = (NonLeafAttribute)boundValues[0];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ @Nullable Attribute attribute = fa_0.getAttribute();
			final /*@NonInvalid*/ boolean symbol_0 = attribute != null;
			/*@Thrown*/ @Nullable Boolean raw_a;
			if (symbol_0) {
				if (attribute == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				@SuppressWarnings("null")
				final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = attribute.getOwner();
				final /*@Thrown*/ @Nullable ClassToTable middle = OPPOSITE_OF_ClassToTable_umlClass.get(owner);
				final /*@Thrown*/ boolean symbol_1 = middle != null;
				/*@Thrown*/ @Nullable Boolean raw_fao;
				if (symbol_1) {
					if (middle == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					@SuppressWarnings("null")
					final /*@Thrown*/ @NonNull List<FromAttribute> fromAttributes = middle.getFromAttributes();
					// mapping statements
					fa_0.setOwner(middle);
					final /*@Thrown*/ @NonNull SetValue BOXED_fromAttributes = idResolver.createSetOfAll(SET_CLSSid_FromAttribute, fromAttributes);
					/*@Thrown*/ BagValue.@NonNull Accumulator accumulator = ValueUtil.createBagAccumulatorValue(BAG_CLSSid_AttributeToColumn);
					@NonNull Iterator<Object> ITERATOR__1 = BOXED_fromAttributes.iterator();
					/*@Thrown*/ @NonNull BagValue collect;
					while (true) {
						if (!ITERATOR__1.hasNext()) {
							collect = accumulator;
							break;
						}
						@SuppressWarnings("null")
						/*@NonInvalid*/ @NonNull FromAttribute _1 = (FromAttribute)ITERATOR__1.next();
						/**
						 * _'1_'.leafs
						 */
						objectManager.getting(_1, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, false);
						@SuppressWarnings("null")
						final /*@NonInvalid*/ @NonNull List<AttributeToColumn> leafs = _1.getLeafs();
						final /*@NonInvalid*/ @NonNull SetValue BOXED_leafs = idResolver.createSetOfAll(SET_CLSSid_AttributeToColumn, leafs);
						//
						for (Object value : BOXED_leafs.flatten().getElements()) {
							accumulator.add(value);
						}
					}
					final /*@Thrown*/ @NonNull SetValue asSet = CollectionAsSetOperation.INSTANCE.evaluate(collect);
					final /*@Thrown*/ @NonNull List<AttributeToColumn> ECORE_asSet = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(AttributeToColumn.class, asSet);
					fa_0.getLeafs().addAll(ECORE_asSet);
					objectManager.assigned(fa_0, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, ECORE_asSet, null);
					final /*@Thrown*/ @Nullable Boolean m_NonLeafAttribute_leafs_owner_p1 = ValueUtil.TRUE_VALUE;
					raw_fao = m_NonLeafAttribute_leafs_owner_p1;
				}
				else {
					raw_fao = ValueUtil.FALSE_VALUE;
				}
				raw_a = raw_fao;
			}
			else {
				raw_a = ValueUtil.FALSE_VALUE;
			}
			return raw_a;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(fa_0, thoseValues[0]);
		}
	}

	/**
	 *
	 * map m_AttributeToColumn_leafs_name_owner_type_p1 in umlRdbms {
	 * guard:middle fa  : simpleuml2rdbms::AttributeToColumn[1];
	 * guard:middle fao  : simpleuml2rdbms::NonLeafAttribute[1];
	 * var a : simpleuml::Attribute[1] := fa.attribute;
	 * var ca : simpleuml::Attribute[1] := fao.attribute;
	 * var name : String[?] := fao.name;
	 * var c : simpleuml::Class[1] := a.owner;
	 * var name1 : String[?] := a.name;
	 * check var t : simpleuml::PrimitiveDataType[1] := a.type;
	 * var p2n : simpleuml2rdbms::PrimitiveToName[1] := t.middle;
	 * check c =
	 *   ca.type;
	 * notify set fa.leafs := Set{fa
	 *   };
	 * set fa.owner := fao;
	 * notify set fa.type := p2n;
	 * notify set fa.name := name + '_' + name1;
	 *
	 */
	protected class MAP_m_AttributeToColumn_leafs_name_owner_type_p1 extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull AttributeToColumn fa_1;
		protected final /*@NonInvalid*/ @NonNull NonLeafAttribute fao;

		public MAP_m_AttributeToColumn_leafs_name_owner_type_p1(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			fa_1 = (AttributeToColumn)boundValues[0];
			fao = (NonLeafAttribute)boundValues[1];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ @Nullable Attribute attribute = fa_1.getAttribute();
			final /*@NonInvalid*/ boolean symbol_0 = attribute != null;
			/*@Thrown*/ @Nullable Boolean raw_a;
			if (symbol_0) {
				if (attribute == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				final /*@NonInvalid*/ @Nullable Attribute attribute_0 = fao.getAttribute();
				final /*@NonInvalid*/ boolean symbol_1 = attribute_0 != null;
				/*@Thrown*/ @Nullable Boolean raw_ca;
				if (symbol_1) {
					if (attribute_0 == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					objectManager.getting(fao, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, false);
					final /*@NonInvalid*/ @Nullable String name = fao.getName();
					@SuppressWarnings("null")
					final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = attribute.getOwner();
					final /*@Thrown*/ @Nullable String name_0 = attribute.getName();
					@SuppressWarnings("null")
					final /*@Thrown*/ @NonNull Classifier temp1_t = attribute.getType();
					final /*@NonInvalid*/ boolean symbol_2 = temp1_t instanceof PrimitiveDataType;
					/*@Thrown*/ @Nullable Boolean symbol_12;
					if (symbol_2) {
						final /*@Thrown*/ @NonNull PrimitiveDataType symbol_3 = (PrimitiveDataType)temp1_t;
						final /*@Thrown*/ @Nullable PrimitiveToName middle = OPPOSITE_OF_PrimitiveToName_primitive.get(symbol_3);
						final /*@Thrown*/ boolean symbol_4 = middle != null;
						/*@Thrown*/ @Nullable Boolean raw_p2n;
						if (symbol_4) {
							if (middle == null) {
								throw new InvalidEvaluationException("Null where non-null value required");
							}
							@SuppressWarnings("null")
							final /*@Thrown*/ @NonNull Classifier type = attribute_0.getType();
							final /*@Thrown*/ boolean symbol_5 = owner.equals(type);
							/*@Thrown*/ @Nullable Boolean symbol_11;
							if (symbol_5) {
								// mapping statements
								final /*@NonInvalid*/ @NonNull SetValue Set = ValueUtil.createSetOfEach(SET_CLSSid_AttributeToColumn, fa_1);
								final /*@NonInvalid*/ @NonNull List<AttributeToColumn> ECORE_Set = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(AttributeToColumn.class, Set);
								fa_1.getLeafs().addAll(ECORE_Set);
								objectManager.assigned(fa_1, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, ECORE_Set, null);
								fa_1.setOwner(fao);
								fa_1.setType(middle);
								objectManager.assigned(fa_1, Simpleuml2rdbmsPackage.Literals.ATTRIBUTE_TO_COLUMN__TYPE, middle, null);
								final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR__);
								final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(sum, name_0);
								fa_1.setName(sum_0);
								objectManager.assigned(fa_1, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, sum_0, null);
								final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn_leafs_name_owner_type_p1 = ValueUtil.TRUE_VALUE;
								symbol_11 = m_AttributeToColumn_leafs_name_owner_type_p1;
							}
							else {
								symbol_11 = ValueUtil.FALSE_VALUE;
							}
							raw_p2n = symbol_11;
						}
						else {
							raw_p2n = ValueUtil.FALSE_VALUE;
						}
						symbol_12 = raw_p2n;
					}
					else {
						symbol_12 = ValueUtil.FALSE_VALUE;
					}
					raw_ca = symbol_12;
				}
				else {
					raw_ca = ValueUtil.FALSE_VALUE;
				}
				raw_a = raw_ca;
			}
			else {
				raw_a = ValueUtil.FALSE_VALUE;
			}
			return raw_a;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(fa_1, thoseValues[0])
				&& idResolver.oclEquals(fao, thoseValues[1]);
		}
	}

	/**
	 *
	 * map m_AttributeToColumn_column in umlRdbms {
	 *
	 *   guard:middle a2c  : simpleuml2rdbms::AttributeToColumn[1];
	 * check var c2t : simpleuml2rdbms::ClassToTable[1] := a2c.owner;
	 * var kind : String[?] := a2c.kind;
	 * var name : String[?] := a2c.name;
	 * var fromAttributes : Set(simpleuml2rdbms::FromAttribute) := c2t.fromAttributes;
	 * var t : simplerdbms::Table[1] := c2t.table;
	 * check fromAttributes->collect(_'1_' | _'1_'.leafs)
	 *   ->includes(a2c);
	 * contained new:rdbms c : simplerdbms::Column[1];
	 * notify set a2c.column := c;
	 * set c.kind := kind;
	 * set c.name := name;
	 * notify set c.owner := t;
	 *
	 */
	protected class MAP_m_AttributeToColumn_column extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull AttributeToColumn a2c;

		public MAP_m_AttributeToColumn_column(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			a2c = (AttributeToColumn)boundValues[0];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			@SuppressWarnings("null")
			final /*@NonInvalid*/ @NonNull FromAttributeOwner temp1_c2t = a2c.getOwner();
			final /*@NonInvalid*/ boolean symbol_0 = temp1_c2t instanceof ClassToTable;
			/*@Thrown*/ @Nullable Boolean symbol_9;
			if (symbol_0) {
				final /*@NonInvalid*/ @NonNull ClassToTable symbol_1 = (ClassToTable)temp1_c2t;
				final /*@NonInvalid*/ @Nullable String kind = a2c.getKind();
				objectManager.getting(a2c, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, false);
				final /*@NonInvalid*/ @Nullable String name = a2c.getName();
				@SuppressWarnings("null")
				final /*@NonInvalid*/ @NonNull List<FromAttribute> fromAttributes = symbol_1.getFromAttributes();
				final /*@NonInvalid*/ @Nullable Table table = symbol_1.getTable();
				final /*@NonInvalid*/ boolean symbol_2 = table != null;
				/*@Thrown*/ @Nullable Boolean raw_t;
				if (symbol_2) {
					if (table == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					final /*@NonInvalid*/ @NonNull SetValue BOXED_fromAttributes = idResolver.createSetOfAll(SET_CLSSid_FromAttribute, fromAttributes);
					/*@Thrown*/ BagValue.@NonNull Accumulator accumulator = ValueUtil.createBagAccumulatorValue(BAG_CLSSid_AttributeToColumn);
					@NonNull Iterator<Object> ITERATOR__1 = BOXED_fromAttributes.iterator();
					/*@NonInvalid*/ @NonNull BagValue collect;
					while (true) {
						if (!ITERATOR__1.hasNext()) {
							collect = accumulator;
							break;
						}
						@SuppressWarnings("null")
						/*@NonInvalid*/ @NonNull FromAttribute _1 = (FromAttribute)ITERATOR__1.next();
						/**
						 * _'1_'.leafs
						 */
						objectManager.getting(_1, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, false);
						@SuppressWarnings("null")
						final /*@NonInvalid*/ @NonNull List<AttributeToColumn> leafs = _1.getLeafs();
						final /*@NonInvalid*/ @NonNull SetValue BOXED_leafs = idResolver.createSetOfAll(SET_CLSSid_AttributeToColumn, leafs);
						//
						for (Object value : BOXED_leafs.flatten().getElements()) {
							accumulator.add(value);
						}
					}
					final /*@NonInvalid*/ boolean includes = CollectionIncludesOperation.INSTANCE.evaluate(collect, a2c).booleanValue();
					/*@Thrown*/ @Nullable Boolean symbol_8;
					if (includes) {
						// creations
						final @SuppressWarnings("null")@NonNull Column c_0 = SimplerdbmsFactory.eINSTANCE.createColumn();
						models[1/*rdbms*/].add(c_0, true);
						// mapping statements
						a2c.setColumn(c_0);
						objectManager.assigned(a2c, Simpleuml2rdbmsPackage.Literals.TO_COLUMN__COLUMN, c_0, null);
						c_0.setKind(kind);
						c_0.setName(name);
						c_0.setOwner(table);
						objectManager.assigned(c_0, SimplerdbmsPackage.Literals.COLUMN__OWNER, table, null);
						final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn_column = ValueUtil.TRUE_VALUE;
						symbol_8 = m_AttributeToColumn_column;
					}
					else {
						symbol_8 = ValueUtil.FALSE_VALUE;
					}
					raw_t = symbol_8;
				}
				else {
					raw_t = ValueUtil.FALSE_VALUE;
				}
				symbol_9 = raw_t;
			}
			else {
				symbol_9 = ValueUtil.FALSE_VALUE;
			}
			return symbol_9;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(a2c, thoseValues[0]);
		}
	}

	/**
	 *
	 * map m_AttributeToColumn__type in umlRdbms {
	 * guard:middle a2c  : simpleuml2rdbms::AttributeToColumn[1];
	 * var c : simplerdbms::Column[1] := a2c.column;
	 * check var c2t : simpleuml2rdbms::ClassToTable[1] := a2c.owner;
	 * var p2n : simpleuml2rdbms::PrimitiveToName[1] := a2c.type;
	 * var ct : String[1] := p2n.typeName;
	 * var fromAttributes : Set(simpleuml2rdbms::FromAttribute) := c2t.fromAttributes;
	 * var t : simplerdbms::Table[1] := c.owner;
	 * check t =
	 *   c2t.table;
	 * check fromAttributes->collect(_'1_' | _'1_'.leafs)
	 *   ->includes(a2c);
	 * notify set c.type := ct;
	 *
	 */
	protected class MAP_m_AttributeToColumn__type extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull AttributeToColumn a2c_0;

		public MAP_m_AttributeToColumn__type(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			a2c_0 = (AttributeToColumn)boundValues[0];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			objectManager.getting(a2c_0, Simpleuml2rdbmsPackage.Literals.TO_COLUMN__COLUMN, false);
			@SuppressWarnings("null")
			final /*@NonInvalid*/ @NonNull Column column = a2c_0.getColumn();
			@SuppressWarnings("null")
			final /*@NonInvalid*/ @NonNull FromAttributeOwner temp1_c2t = a2c_0.getOwner();
			final /*@NonInvalid*/ boolean symbol_0 = temp1_c2t instanceof ClassToTable;
			/*@Thrown*/ @Nullable Boolean symbol_8;
			if (symbol_0) {
				final /*@NonInvalid*/ @NonNull ClassToTable symbol_1 = (ClassToTable)temp1_c2t;
				objectManager.getting(a2c_0, Simpleuml2rdbmsPackage.Literals.ATTRIBUTE_TO_COLUMN__TYPE, false);
				final /*@NonInvalid*/ @Nullable PrimitiveToName type = a2c_0.getType();
				final /*@NonInvalid*/ boolean symbol_2 = type != null;
				/*@Thrown*/ @Nullable Boolean raw_p2n;
				if (symbol_2) {
					if (type == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					@SuppressWarnings("null")
					final /*@Thrown*/ @NonNull String typeName = type.getTypeName();
					@SuppressWarnings("null")
					final /*@NonInvalid*/ @NonNull List<FromAttribute> fromAttributes = symbol_1.getFromAttributes();
					objectManager.getting(column, SimplerdbmsPackage.Literals.COLUMN__OWNER, false);
					@SuppressWarnings("null")
					final /*@NonInvalid*/ @NonNull Table owner = column.getOwner();
					final /*@NonInvalid*/ @Nullable Table table = symbol_1.getTable();
					final /*@NonInvalid*/ boolean symbol_3 = owner.equals(table);
					/*@Thrown*/ @Nullable Boolean symbol_7;
					if (symbol_3) {
						final /*@NonInvalid*/ @NonNull SetValue BOXED_fromAttributes = idResolver.createSetOfAll(SET_CLSSid_FromAttribute, fromAttributes);
						/*@Thrown*/ BagValue.@NonNull Accumulator accumulator = ValueUtil.createBagAccumulatorValue(BAG_CLSSid_AttributeToColumn);
						@NonNull Iterator<Object> ITERATOR__1 = BOXED_fromAttributes.iterator();
						/*@NonInvalid*/ @NonNull BagValue collect;
						while (true) {
							if (!ITERATOR__1.hasNext()) {
								collect = accumulator;
								break;
							}
							@SuppressWarnings("null")
							/*@NonInvalid*/ @NonNull FromAttribute _1 = (FromAttribute)ITERATOR__1.next();
							/**
							 * _'1_'.leafs
							 */
							objectManager.getting(_1, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, false);
							@SuppressWarnings("null")
							final /*@NonInvalid*/ @NonNull List<AttributeToColumn> leafs = _1.getLeafs();
							final /*@NonInvalid*/ @NonNull SetValue BOXED_leafs = idResolver.createSetOfAll(SET_CLSSid_AttributeToColumn, leafs);
							//
							for (Object value : BOXED_leafs.flatten().getElements()) {
								accumulator.add(value);
							}
						}
						final /*@NonInvalid*/ boolean includes = CollectionIncludesOperation.INSTANCE.evaluate(collect, a2c_0).booleanValue();
						/*@Thrown*/ @Nullable Boolean symbol_6;
						if (includes) {
							// mapping statements
							column.setType(typeName);
							objectManager.assigned(column, SimplerdbmsPackage.Literals.COLUMN__TYPE, typeName, null);
							final /*@Thrown*/ @Nullable Boolean m_AttributeToColumn__type = ValueUtil.TRUE_VALUE;
							symbol_6 = m_AttributeToColumn__type;
						}
						else {
							symbol_6 = ValueUtil.FALSE_VALUE;
						}
						symbol_7 = symbol_6;
					}
					else {
						symbol_7 = ValueUtil.FALSE_VALUE;
					}
					raw_p2n = symbol_7;
				}
				else {
					raw_p2n = ValueUtil.FALSE_VALUE;
				}
				symbol_8 = raw_p2n;
			}
			else {
				symbol_8 = ValueUtil.FALSE_VALUE;
			}
			return symbol_8;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(a2c_0, thoseValues[0]);
		}
	}

	/**
	 *
	 * map m_NonLeafAttribute_leafs_name_owner_p1 in umlRdbms {
	 * guard:middle fa  : simpleuml2rdbms::NonLeafAttribute[1];
	 * guard:middle fao  : simpleuml2rdbms::NonLeafAttribute[1];
	 * var a : simpleuml::Attribute[1] := fa.attribute;
	 * var ca : simpleuml::Attribute[1] := fao.attribute;
	 * var fromAttributes : Set(simpleuml2rdbms::FromAttribute) := fao.fromAttributes;
	 * var name : String[?] := fao.name;
	 * var c : simpleuml::Class[1] := a.owner;
	 * var name1 : String[?] := a.name;
	 * check c =
	 *   ca.type;
	 * set fa.owner := fao;
	 * notify set fa.leafs := fromAttributes->collect(_'1_' | _'1_'.leafs)
	 *   ->asSet();
	 * notify set fa.name := name + '_' + name1;
	 *
	 */
	protected class MAP_m_NonLeafAttribute_leafs_name_owner_p1 extends AbstractInvocation
	{
		protected final /*@NonInvalid*/ @NonNull NonLeafAttribute fa_2;
		protected final /*@NonInvalid*/ @NonNull NonLeafAttribute fao_0;

		public MAP_m_NonLeafAttribute_leafs_name_owner_p1(@NonNull InvocationConstructor constructor, @NonNull Object @NonNull [] boundValues) {
			super(constructor);
			fa_2 = (NonLeafAttribute)boundValues[0];
			fao_0 = (NonLeafAttribute)boundValues[1];
		}

		@Override
		public boolean execute()  {
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ @Nullable Attribute attribute = fa_2.getAttribute();
			final /*@NonInvalid*/ boolean symbol_0 = attribute != null;
			/*@Thrown*/ @Nullable Boolean raw_a;
			if (symbol_0) {
				if (attribute == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				final /*@NonInvalid*/ @Nullable Attribute attribute_0 = fao_0.getAttribute();
				final /*@NonInvalid*/ boolean symbol_1 = attribute_0 != null;
				/*@Thrown*/ @Nullable Boolean raw_ca;
				if (symbol_1) {
					if (attribute_0 == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					@SuppressWarnings("null")
					final /*@NonInvalid*/ @NonNull List<FromAttribute> fromAttributes = fao_0.getFromAttributes();
					objectManager.getting(fao_0, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, false);
					final /*@NonInvalid*/ @Nullable String name = fao_0.getName();
					@SuppressWarnings("null")
					final /*@Thrown*/ org.eclipse.qvtd.examples.qvtcore.uml2rdbms.simpleuml.@NonNull Class owner = attribute.getOwner();
					final /*@Thrown*/ @Nullable String name_0 = attribute.getName();
					@SuppressWarnings("null")
					final /*@Thrown*/ @NonNull Classifier type = attribute_0.getType();
					final /*@Thrown*/ boolean symbol_2 = owner.equals(type);
					/*@Thrown*/ @Nullable Boolean symbol_7;
					if (symbol_2) {
						// mapping statements
						fa_2.setOwner(fao_0);
						final /*@NonInvalid*/ @NonNull SetValue BOXED_fromAttributes = idResolver.createSetOfAll(SET_CLSSid_FromAttribute, fromAttributes);
						/*@Thrown*/ BagValue.@NonNull Accumulator accumulator = ValueUtil.createBagAccumulatorValue(BAG_CLSSid_AttributeToColumn);
						@NonNull Iterator<Object> ITERATOR__1 = BOXED_fromAttributes.iterator();
						/*@NonInvalid*/ @NonNull BagValue collect;
						while (true) {
							if (!ITERATOR__1.hasNext()) {
								collect = accumulator;
								break;
							}
							@SuppressWarnings("null")
							/*@NonInvalid*/ @NonNull FromAttribute _1 = (FromAttribute)ITERATOR__1.next();
							/**
							 * _'1_'.leafs
							 */
							objectManager.getting(_1, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, false);
							@SuppressWarnings("null")
							final /*@NonInvalid*/ @NonNull List<AttributeToColumn> leafs = _1.getLeafs();
							final /*@NonInvalid*/ @NonNull SetValue BOXED_leafs = idResolver.createSetOfAll(SET_CLSSid_AttributeToColumn, leafs);
							//
							for (Object value : BOXED_leafs.flatten().getElements()) {
								accumulator.add(value);
							}
						}
						final /*@NonInvalid*/ @NonNull SetValue asSet = CollectionAsSetOperation.INSTANCE.evaluate(collect);
						final /*@NonInvalid*/ @NonNull List<AttributeToColumn> ECORE_asSet = ((IdResolver.IdResolverExtension)idResolver).ecoreValueOfAll(AttributeToColumn.class, asSet);
						fa_2.getLeafs().addAll(ECORE_asSet);
						objectManager.assigned(fa_2, Simpleuml2rdbmsPackage.Literals.FROM_ATTRIBUTE__LEAFS, ECORE_asSet, null);
						final /*@Thrown*/ @NonNull String sum = StringConcatOperation.INSTANCE.evaluate(name, STR__);
						final /*@Thrown*/ @NonNull String sum_0 = StringConcatOperation.INSTANCE.evaluate(sum, name_0);
						fa_2.setName(sum_0);
						objectManager.assigned(fa_2, Simpleuml2rdbmsPackage.Literals.UML_TO_RDBMS_MODEL_ELEMENT__NAME, sum_0, null);
						final /*@Thrown*/ @Nullable Boolean m_NonLeafAttribute_leafs_name_owner_p1 = ValueUtil.TRUE_VALUE;
						symbol_7 = m_NonLeafAttribute_leafs_name_owner_p1;
					}
					else {
						symbol_7 = ValueUtil.FALSE_VALUE;
					}
					raw_ca = symbol_7;
				}
				else {
					raw_ca = ValueUtil.FALSE_VALUE;
				}
				raw_a = raw_ca;
			}
			else {
				raw_a = ValueUtil.FALSE_VALUE;
			}
			return raw_a;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @NonNull Object @NonNull [] thoseValues) {
			return idResolver.oclEquals(fa_2, thoseValues[0])
				&& idResolver.oclEquals(fao_0, thoseValues[1]);
		}
	}
}

/*******************************************************************************
 * «codeGenHelper.getCopyright(' * ')»
 *
 * This code is 100% auto-generated
 * using: org.eclipse.qvtd.codegen.qvti.java.QVTiCodeGenerator
 *
 * Do not edit it.
 ********************************************************************************/

package org.eclipse.qvtd.examples.qvtrelation.hstm2fstm;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.jdt.annotation.Nullable;
import org.eclipse.ocl.pivot.StandardLibrary;
import org.eclipse.ocl.pivot.evaluation.Executor;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.NestedPackageId;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.PropertyId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorSingleIterationManager;
import org.eclipse.ocl.pivot.library.AbstractBinaryOperation;
import org.eclipse.ocl.pivot.library.LibraryIteration;
import org.eclipse.ocl.pivot.library.collection.CollectionExcludingOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionIncludesOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionIsEmptyOperation;
import org.eclipse.ocl.pivot.library.oclany.OclAnyOclAsSetOperation;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.ClassUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.SetValue;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.HierarchicalStateMachine2FlatStateMachine;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.FlatStateMachineFactory;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.FlatStateMachinePackage;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.HierarchicalStateMachinePackage;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.PHierarchicalStateMachine2FlatStateMachine.PHierarchicalStateMachine2FlatStateMachineFactory;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.PHierarchicalStateMachine2FlatStateMachine.PHierarchicalStateMachine2FlatStateMachinePackage;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.PHierarchicalStateMachine2FlatStateMachine.THierachicalStateMachine2FlatStateMachine;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.PHierarchicalStateMachine2FlatStateMachine.THierachicalTransition2FlatTransition;
import org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.PHierarchicalStateMachine2FlatStateMachine.TLeafState2FlatState;
import org.eclipse.qvtd.runtime.evaluation.AbstractComputation;
import org.eclipse.qvtd.runtime.evaluation.AbstractTransformer;
import org.eclipse.qvtd.runtime.evaluation.Connection;
import org.eclipse.qvtd.runtime.evaluation.InvalidEvaluationException;
import org.eclipse.qvtd.runtime.evaluation.TransformationExecutor;
import org.eclipse.qvtd.runtime.internal.evaluation.AbstractComputationConstructor;

/**
 * The HierarchicalStateMachine2FlatStateMachine transformation:
 * <p>
 * Construct with an evaluator
 * <br>
 * Populate each input model with {@link addRootObjects(String,List)}
 * <br>
 * {@link run()}
 * <br>
 * Extract each output model with {@link getRootObjects(String)}
 */
@SuppressWarnings("unused")
public class HierarchicalStateMachine2FlatStateMachine extends AbstractTransformer
{
	public static final /*@NonInvalid*/ @NonNull RootPackageId PACKid_org = IdManager.getRootPackageId("org");
	public static final /*@NonInvalid*/ @NonNull NestedPackageId PACKid_eclipse = PACKid_org.getNestedPackageId("eclipse");
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_m_example_s_org_s_eclipse_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine2FlatStateMachine = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd-example/org/eclipse/qvtd/examples/qvtrelation/hstm2fstm/HierarchicalStateMachine2FlatStateMachine", "PHierarchicalStateMachine2FlatStateMachine", PHierarchicalStateMachine2FlatStateMachinePackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_FlatStateMachine = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd/examples/qvtrelation/hstm2fstm/FlatStateMachine", null, FlatStateMachinePackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine = IdManager.getNsURIPackageId("http://www.eclipse.org/qvtd/examples/qvtrelation/hstm2fstm/HierarchicalStateMachine", null, HierarchicalStateMachinePackage.eINSTANCE);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_State = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine.getClassId("State", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_StateMachine = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine.getClassId("StateMachine", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_StateMachine_0 = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_FlatStateMachine.getClassId("StateMachine", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_State_0 = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_FlatStateMachine.getClassId("State", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_THierachicalStateMachine2FlatStateMachine = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_m_example_s_org_s_eclipse_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine2FlatStateMachine.getClassId("THierachicalStateMachine2FlatStateMachine", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_THierachicalTransition2FlatTransition = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_m_example_s_org_s_eclipse_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine2FlatStateMachine.getClassId("THierachicalTransition2FlatTransition", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_TLeafState2FlatState = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_m_example_s_org_s_eclipse_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine2FlatStateMachine.getClassId("TLeafState2FlatState", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Transition = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_HierarchicalStateMachine.getClassId("Transition", 0);
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_Transition_0 = PACKid_http_c_s_s_www_eclipse_org_s_qvtd_s_examples_s_qvtrelation_s_hstm2fstm_s_FlatStateMachine.getClassId("Transition", 0);
	public static final /*@NonInvalid*/ @NonNull NestedPackageId PACKid_qvtd = PACKid_eclipse.getNestedPackageId("qvtd");
	public static final /*@NonInvalid*/ @NonNull NestedPackageId PACKid_examples = PACKid_qvtd.getNestedPackageId("examples");
	public static final /*@NonInvalid*/ @NonNull PropertyId PROPid_hierarchicalStateMachine_1 = CLSSid_THierachicalStateMachine2FlatStateMachine.getPropertyId("hierarchicalStateMachine");
	public static final /*@NonInvalid*/ @NonNull PropertyId PROPid_leafState = CLSSid_TLeafState2FlatState.getPropertyId("leafState");
	public static final /*@NonInvalid*/ @NonNull CollectionTypeId SET_CLSSid_State = TypeId.SET.getSpecializedId(CLSSid_State);
	public static final /*@NonInvalid*/ @NonNull NestedPackageId PACKid_qvtrelation = PACKid_examples.getNestedPackageId("qvtrelation");
	public static final /*@NonInvalid*/ @NonNull NestedPackageId PACKid_hstm2fstm = PACKid_qvtrelation.getNestedPackageId("hstm2fstm");
	public static final /*@NonInvalid*/ @NonNull ClassId CLSSid_HierarchicalStateMachine2FlatStateMachine = PACKid_hstm2fstm.getClassId("HierarchicalStateMachine2FlatStateMachine", 0);

	/*
	 * Property-source to Property-target unnavigable navigation caches
	 */
	protected final @NonNull Map<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.StateMachine,THierachicalStateMachine2FlatStateMachine> OPPOSITE_OF_THierachicalStateMachine2FlatStateMachine_hierarchicalStateMachine = new HashMap<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.StateMachine,THierachicalStateMachine2FlatStateMachine>();
	protected final @NonNull Map<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State,TLeafState2FlatState> OPPOSITE_OF_TLeafState2FlatState_leafState = new HashMap<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State,TLeafState2FlatState>();

	/*
	 * Array of the source PropertyIds of each Property for which unnavigable opposite property navigation may occur.
	 */
	private static final @NonNull PropertyId @NonNull [] oppositeIndex2propertyId = new @NonNull PropertyId[]{
		PROPid_hierarchicalStateMachine_1,		// 0 => hierarchicalStateMachine
		PROPid_leafState		// 1 => leafState
	};

	/*
	 * Array of the ClassIds of each class for which allInstances() may be invoked. Array index is the ClassIndex.
	 */
	private static final @NonNull ClassId @NonNull [] classIndex2classId = new @NonNull ClassId[]{
		CLSSid_State,                         // 0 => State
		CLSSid_StateMachine,                  // 1 => StateMachine
		CLSSid_Transition                     // 2 => Transition
	};

	/*
	 * Mapping from each ClassIndex to all the ClassIndexes to which an object of the outer index
	 * may contribute results to an allInstances() invocation.
	 * Non trivial inner arrays arise when one ClassId is a derivation of another and so an
	 * instance of the derived classId contributes to derived and inherited ClassIndexes.
	 */
	private final static int @NonNull [] @NonNull [] classIndex2allClassIndexes = new int @NonNull [] @NonNull [] {
		{0},                          // 0 : State -> {State}
		{1},                          // 1 : StateMachine -> {StateMachine}
		{2}                           // 2 : Transition -> {Transition}
	};

	protected final @NonNull AbstractComputationConstructor FTOR_getLeafStates = new AbstractComputationConstructor(idResolver)
	{
		@Override
		public @NonNull FUN_getLeafStates newInstance(@Nullable Object @NonNull [] values) {
			return new FUN_getLeafStates(values);
		}
	};


	public HierarchicalStateMachine2FlatStateMachine(final @NonNull TransformationExecutor executor) {
		super(executor, new @NonNull String[] {"middle", "hier", "flat", "$primitive$"}, oppositeIndex2propertyId, classIndex2classId, classIndex2allClassIndexes);
	}

	@Override
	public boolean run() {
		final @NonNull Connection ji_State = models[1/*hier*/].getConnection(0/*HierarchicalStateMachine::State*/);
		final @NonNull Connection ji_StateMachine = models[1/*hier*/].getConnection(1/*HierarchicalStateMachine::StateMachine*/);
		final @NonNull Connection ji_Transition = models[1/*hier*/].getConnection(2/*HierarchicalStateMachine::Transition*/);
		return MAP___root__(ji_State, ji_StateMachine, ji_Transition) && invocationManager.flush();
	}

	/**
	 * ::getLeafStates(hierarchicalState : HierarchicalStateMachine::State[1]) : Set(HierarchicalStateMachine::State)
	 */
	protected class FUN_getLeafStates extends AbstractComputation
	{
		protected final @NonNull HierarchicalStateMachine2FlatStateMachine self;
		protected /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State hierarchicalState;
		protected final /*@Thrown*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> instance;

		/**
		 *
		 * hierarchicalState->closure(nestedStates)
		 * ?->select(nestedStates->isEmpty())
		 */
		public FUN_getLeafStates(/*Nullable*/ Object @NonNull [] boundValues) {
			this.self = (HierarchicalStateMachine2FlatStateMachine)boundValues[0];
			this.hierarchicalState = (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State)boundValues[1];
			final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ @NonNull StandardLibrary standardLibrary = idResolver.getStandardLibrary();
			final /*@NonInvalid*/ @NonNull SetValue oclAsSet = OclAnyOclAsSetOperation.INSTANCE.evaluate(executor, SET_CLSSid_State, hierarchicalState);
			final org.eclipse.ocl.pivot.@NonNull Class TYPE_closure_0 = executor.getStaticTypeOf(oclAsSet);
			final LibraryIteration.@NonNull LibraryIterationExtension IMPL_closure_0 = (LibraryIteration.LibraryIterationExtension)TYPE_closure_0.lookupImplementation(standardLibrary, OCLstdlibTables.Operations._Set__closure);
			final @NonNull Object ACC_closure_0 = IMPL_closure_0.createAccumulatorValue(executor, SET_CLSSid_State, SET_CLSSid_State);
			/**
			 * Implementation of the iterator body.
			 */
			final @NonNull AbstractBinaryOperation BODY_closure_0 = new AbstractBinaryOperation()
			{
				/**
				 * nestedStates
				 */
				@Override
				public @Nullable Object evaluate(final @NonNull Executor executor, final @NonNull TypeId typeId, final @Nullable Object oclAsSet, final /*@NonInvalid*/ @Nullable Object _1) {
					final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@Nullable State symbol_0 = (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State)_1;
					if (symbol_0 == null) {
						throw new InvalidEvaluationException("Null source for \'\'http://www.eclipse.org/qvtd/examples/qvtrelation/hstm2fstm/HierarchicalStateMachine\'::State::nestedStates\'");
					}
					@SuppressWarnings("null")
					final /*@Thrown*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> nestedStates = symbol_0.getNestedStates();
					final /*@Thrown*/ @NonNull SetValue BOXED_nestedStates = idResolver.createSetOfAll(SET_CLSSid_State, nestedStates);
					return BOXED_nestedStates;
				}
			};
			final @NonNull  ExecutorSingleIterationManager MGR_closure_0 = new ExecutorSingleIterationManager(executor, SET_CLSSid_State, BODY_closure_0, oclAsSet, ACC_closure_0);
			final /*@Thrown*/ @NonNull SetValue closure = ClassUtil.nonNullState((SetValue)IMPL_closure_0.evaluateIteration(MGR_closure_0));
			final /*@Thrown*/ @NonNull SetValue safe_null_sources = (SetValue)CollectionExcludingOperation.INSTANCE.evaluate(closure, (Object)null);
			/*@Thrown*/ SetValue.@NonNull Accumulator accumulator = ValueUtil.createSetAccumulatorValue(SET_CLSSid_State);
			@NonNull Iterator<Object> ITERATOR__1_0 = safe_null_sources.iterator();
			/*@Thrown*/ @NonNull SetValue select;
			while (true) {
				if (!ITERATOR__1_0.hasNext()) {
					select = accumulator;
					break;
				}
				@SuppressWarnings("null")
				/*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State _1_0 = (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State)ITERATOR__1_0.next();
				/**
				 * nestedStates->isEmpty()
				 */
				@SuppressWarnings("null")
				final /*@NonInvalid*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> nestedStates_0 = _1_0.getNestedStates();
				final /*@NonInvalid*/ @NonNull SetValue BOXED_nestedStates_0 = idResolver.createSetOfAll(SET_CLSSid_State, nestedStates_0);
				final /*@NonInvalid*/ boolean isEmpty = CollectionIsEmptyOperation.INSTANCE.evaluate(BOXED_nestedStates_0).booleanValue();
				//
				if (isEmpty == ValueUtil.TRUE_VALUE) {
					accumulator.add(_1_0);
				}
			}
			final List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> UNBOXED_select = select.asEcoreObjects(idResolver, org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State.class);
			assert UNBOXED_select != null;
			this.instance = UNBOXED_select;
		}

		@Override
		public @Nullable Object getResult() {
			return instance;
		}

		@Override
		public boolean isEqual(@NonNull IdResolver idResolver, @Nullable Object @NonNull [] thoseValues) {
			return this.self == thoseValues[0]
				&& idResolver.oclEquals(this.hierarchicalState, thoseValues[1]);
		}
	}

	/**
	 *
	 * map __root__ in HierarchicalStateMachine2FlatStateMachine {
	 *
	 *   append ji_State  : HierarchicalStateMachine::State[1];
	 * append ji_StateMachine  : HierarchicalStateMachine::StateMachine[1];
	 * append ji_Transition  : HierarchicalStateMachine::Transition[1];
	 * ::jm_THierachicalTransition2FlatTransition : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1]::jm_TLeafState2FlatState : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1]install m_THierachicalStateMachine2FlatStateMachine_flatStat_r0 {
	 * hierarchicalStateMachine consumes append ji_StateMachine  : HierarchicalStateMachine::StateMachine[1];
	 * ;
	 * }
	 *   install m_THierachicalTransition2FlatTransition_hierarchical_p0 {
	 * hierarchicalTransition consumes append ji_Transition  : HierarchicalStateMachine::Transition[1];
	 * ;
	 * jm_THierachicalTransition2FlatTransition appendsTo jm_THierachicalTransition2FlatTransition;
	 * leafFromState consumes append ji_State  : HierarchicalStateMachine::State[1];
	 * ;
	 * leafToState consumes append ji_State  : HierarchicalStateMachine::State[1];
	 * ;
	 * }
	 *   install m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0 {
	 * jm_TLeafState2FlatState appendsTo jm_TLeafState2FlatState;
	 * leafState consumes append ji_State  : HierarchicalStateMachine::State[1];
	 * ;
	 * }
	 *   install m_THierachicalTransition2FlatTransition_flatStateMac_lc {
	 * trace consumes ::jm_THierachicalTransition2FlatTransition : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * }
	 *   install m_TLeafState2FlatState_flatState_p1 {
	 * trace consumes ::jm_TLeafState2FlatState : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * }
	 *   install m_THierachicalTransition2FlatTransition_flatFromStat_p2 {
	 * trace consumes ::jm_THierachicalTransition2FlatTransition : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * }
	 *   install m_TLeafState2FlatState_flatStateMachine_p2 {
	 * trace consumes ::jm_TLeafState2FlatState : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * }
	 *   install m_THierachicalTransition2FlatTransition_flatToState_p4 {
	 * trace consumes ::jm_THierachicalTransition2FlatTransition : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * }
	 */
	protected boolean MAP___root__(final @NonNull Connection ji_State, final @NonNull Connection ji_StateMachine, final @NonNull Connection ji_Transition)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP___root__" + ", " + ji_State + ", " + ji_StateMachine + ", " + ji_Transition);
		}
		// connection variables
		final @NonNull Connection jm_THierachicalTransition2FlatTransition_1 = createConnection("jm_THierachicalTransition2FlatTransition", CLSSid_THierachicalTransition2FlatTransition, false);
		final @NonNull Connection jm_TLeafState2FlatState_1 = createConnection("jm_TLeafState2FlatState", CLSSid_TLeafState2FlatState, false);
		// mapping statements
		for (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine hierarchicalStateMachine_0 : ji_StateMachine.typedIterable(org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.StateMachine.class)) {
			MAP_m_THierachicalStateMachine2FlatStateMachine_flatStat_r0(hierarchicalStateMachine_0);
		}
		for (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull Transition hierarchicalTransition_0 : ji_Transition.typedIterable(org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.Transition.class)) {
			for (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafFromState_0 : ji_State.typedIterable(org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State.class)) {
				for (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafToState_0 : ji_State.typedIterable(org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State.class)) {
					MAP_m_THierachicalTransition2FlatTransition_hierarchical_p0(hierarchicalTransition_0, jm_THierachicalTransition2FlatTransition_1, leafFromState_0, leafToState_0);
				}
			}
		}
		for (org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafState_0 : ji_State.typedIterable(org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State.class)) {
			MAP_m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0(jm_TLeafState2FlatState_1, leafState_0);
		}
		for (@NonNull THierachicalTransition2FlatTransition trace_4 : jm_THierachicalTransition2FlatTransition_1.typedIterable(THierachicalTransition2FlatTransition.class)) {
			MAP_m_THierachicalTransition2FlatTransition_flatStateMac_lc(trace_4);
		}
		for (@NonNull TLeafState2FlatState trace_5 : jm_TLeafState2FlatState_1.typedIterable(TLeafState2FlatState.class)) {
			MAP_m_TLeafState2FlatState_flatState_p1(trace_5);
		}
		for (@NonNull THierachicalTransition2FlatTransition trace_6 : jm_THierachicalTransition2FlatTransition_1.typedIterable(THierachicalTransition2FlatTransition.class)) {
			MAP_m_THierachicalTransition2FlatTransition_flatFromStat_p2(trace_6);
		}
		for (@NonNull TLeafState2FlatState trace_7 : jm_TLeafState2FlatState_1.typedIterable(TLeafState2FlatState.class)) {
			MAP_m_TLeafState2FlatState_flatStateMachine_p2(trace_7);
		}
		for (@NonNull THierachicalTransition2FlatTransition trace_8 : jm_THierachicalTransition2FlatTransition_1.typedIterable(THierachicalTransition2FlatTransition.class)) {
			MAP_m_THierachicalTransition2FlatTransition_flatToState_p4(trace_8);
		}
		final /*@Thrown*/ @Nullable Boolean __root__ = ValueUtil.TRUE_VALUE;
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((__root__ ? "done "  : "fail ") + "MAP___root__");
		}
		return __root__;
	}

	/**
	 *
	 * map m_THierachicalStateMachine2FlatStateMachine_flatStat_r0 in HierarchicalStateMachine2FlatStateMachine {
	 * guard:hier hierarchicalStateMachine  : HierarchicalStateMachine::StateMachine[1];
	 * var stateMachineName : String[1] := hierarchicalStateMachine.name;
	 * new:flat flatStateMachine : FlatStateMachine::StateMachine[1];
	 * new:middle trace : PHierarchicalStateMachine2FlatStateMachine::THierachicalStateMachine2FlatStateMachine[1];
	 * set trace.flatStateMachine := flatStateMachine;
	 * set trace.hierarchicalStateMachine := hierarchicalStateMachine;
	 * set flatStateMachine.name := stateMachineName;
	 * set trace.stateMachineName := stateMachineName;
	 *
	 */
	protected boolean MAP_m_THierachicalStateMachine2FlatStateMachine_flatStat_r0(final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine hierarchicalStateMachine)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_THierachicalStateMachine2FlatStateMachine_flatStat_r0" + ", " + hierarchicalStateMachine);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull String name = hierarchicalStateMachine.getName();
		// creations
		final @SuppressWarnings("null")org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull StateMachine flatStateMachine = FlatStateMachineFactory.eINSTANCE.createStateMachine();
		models[2/*flat*/].add(flatStateMachine, false);
		final @SuppressWarnings("null")@NonNull THierachicalStateMachine2FlatStateMachine trace_4 = PHierarchicalStateMachine2FlatStateMachineFactory.eINSTANCE.createTHierachicalStateMachine2FlatStateMachine();
		models[0/*middle*/].add(trace_4, false);
		// mapping statements
		trace_4.setFlatStateMachine(flatStateMachine);
		OPPOSITE_OF_THierachicalStateMachine2FlatStateMachine_hierarchicalStateMachine.put(hierarchicalStateMachine, trace_4);
		trace_4.setHierarchicalStateMachine(hierarchicalStateMachine);
		flatStateMachine.setName(name);
		trace_4.setStateMachineName(name);
		final /*@Thrown*/ @Nullable Boolean m_THierachicalStateMachine2FlatStateMachine_flatStat_r0 = ValueUtil.TRUE_VALUE;
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((m_THierachicalStateMachine2FlatStateMachine_flatStat_r0 ? "done "  : "fail ") + "MAP_m_THierachicalStateMachine2FlatStateMachine_flatStat_r0");
		}
		return m_THierachicalStateMachine2FlatStateMachine_flatStat_r0;
	}

	/**
	 *
	 * map m_THierachicalTransition2FlatTransition_hierarchical_p0 in HierarchicalStateMachine2FlatStateMachine {
	 *
	 *   guard:hier hierarchicalTransition  : HierarchicalStateMachine::Transition[1];
	 * guard:hier leafFromState  : HierarchicalStateMachine::State[1];
	 * guard:hier leafToState  : HierarchicalStateMachine::State[1];
	 * append jm_THierachicalTransition2FlatTransition  : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * var hierarchicalFromState : HierarchicalStateMachine::State[1] := hierarchicalTransition.fromState;
	 * var hierarchicalStateMachine : HierarchicalStateMachine::StateMachine[1] := hierarchicalTransition.owningStateMachine;
	 * var hierarchicalToState : HierarchicalStateMachine::State[1] := hierarchicalTransition.toState;
	 * var transitionName : String[1] := hierarchicalTransition.name;
	 * check this.getLeafStates(hierarchicalToState)
	 *   ->includes(leafToState)
	 *   ;
	 * check this.getLeafStates(hierarchicalFromState)
	 *   ->includes(leafFromState);
	 * new:middle trace : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * set trace.hierarchicalTransition := hierarchicalTransition;
	 * set trace.leafFromState := leafFromState;
	 * set trace.leafToState := leafToState;
	 * set trace.transitionName := transitionName;
	 * set trace.hierarchicalFromState := hierarchicalFromState;
	 * set trace.hierarchicalStateMachine := hierarchicalStateMachine;
	 * set trace.hierarchicalToState := hierarchicalToState;
	 * add jm_THierachicalTransition2FlatTransition += trace;
	 *
	 */
	protected boolean MAP_m_THierachicalTransition2FlatTransition_hierarchical_p0(final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull Transition hierarchicalTransition, final org.eclipse.qvtd.runtime.evaluation.@org.eclipse.jdt.annotation.NonNull Connection jm_THierachicalTransition2FlatTransition, final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@org.eclipse.jdt.annotation.NonNull State leafFromState, final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@org.eclipse.jdt.annotation.NonNull State leafToState)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_THierachicalTransition2FlatTransition_hierarchical_p0" + ", " + hierarchicalTransition + ", " + jm_THierachicalTransition2FlatTransition + ", " + leafFromState + ", " + leafToState);
		}
		final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State fromState = hierarchicalTransition.getFromState();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine owningStateMachine = hierarchicalTransition.getOwningStateMachine();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State toState = hierarchicalTransition.getToState();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull String name = hierarchicalTransition.getName();
		final /*@NonInvalid*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> getLeafStates = ((FUN_getLeafStates)FTOR_getLeafStates.getUniqueComputation(this, toState)).instance;
		final /*@NonInvalid*/ @NonNull SetValue BOXED_getLeafStates = idResolver.createSetOfAll(SET_CLSSid_State, getLeafStates);
		final /*@NonInvalid*/ boolean includes = CollectionIncludesOperation.INSTANCE.evaluate(BOXED_getLeafStates, leafToState).booleanValue();
		/*@Thrown*/ @Nullable Boolean symbol_10;
		if (includes) {
			final /*@NonInvalid*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> getLeafStates_0 = ((FUN_getLeafStates)FTOR_getLeafStates.getUniqueComputation(this, fromState)).instance;
			final /*@NonInvalid*/ @NonNull SetValue BOXED_getLeafStates_0 = idResolver.createSetOfAll(SET_CLSSid_State, getLeafStates_0);
			final /*@NonInvalid*/ boolean includes_0 = CollectionIncludesOperation.INSTANCE.evaluate(BOXED_getLeafStates_0, leafFromState).booleanValue();
			/*@Thrown*/ @Nullable Boolean symbol_9;
			if (includes_0) {
				// creations
				final @SuppressWarnings("null")@NonNull THierachicalTransition2FlatTransition trace_4 = PHierarchicalStateMachine2FlatStateMachineFactory.eINSTANCE.createTHierachicalTransition2FlatTransition();
				models[0/*middle*/].add(trace_4, false);
				// mapping statements
				trace_4.setHierarchicalTransition(hierarchicalTransition);
				trace_4.setLeafFromState(leafFromState);
				trace_4.setLeafToState(leafToState);
				trace_4.setTransitionName(name);
				trace_4.setHierarchicalFromState(fromState);
				trace_4.setHierarchicalStateMachine(owningStateMachine);
				trace_4.setHierarchicalToState(toState);
				jm_THierachicalTransition2FlatTransition.appendElement(trace_4);
				final /*@Thrown*/ @Nullable Boolean m_THierachicalTransition2FlatTransition_hierarchical_p0 = ValueUtil.TRUE_VALUE;
				symbol_9 = m_THierachicalTransition2FlatTransition_hierarchical_p0;
			}
			else {
				symbol_9 = ValueUtil.FALSE_VALUE;
			}
			symbol_10 = symbol_9;
		}
		else {
			symbol_10 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_10 ? "done "  : "fail ") + "MAP_m_THierachicalTransition2FlatTransition_hierarchical_p0");
		}
		return symbol_10;
	}

	/**
	 *
	 * map m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0 in HierarchicalStateMachine2FlatStateMachine {
	 *
	 *   guard:hier leafState  : HierarchicalStateMachine::State[1];
	 * append jm_TLeafState2FlatState  : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * var hierarchicalStateMachine : HierarchicalStateMachine::StateMachine[1] := leafState.owningStateMachine;
	 * var nestedStates : Set(HierarchicalStateMachine::State) := leafState.nestedStates;
	 * var stateName : String[1] := leafState.name;
	 * check nestedStates->isEmpty();
	 * new:middle trace : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * set trace.leafState := leafState;
	 * set trace.stateName := stateName;
	 * set trace.hierarchicalStateMachine := hierarchicalStateMachine;
	 * add jm_TLeafState2FlatState += trace;
	 *
	 */
	protected boolean MAP_m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0(final @NonNull Connection jm_TLeafState2FlatState, final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafState)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0" + ", " + jm_TLeafState2FlatState + ", " + leafState);
		}
		final /*@NonInvalid*/ @NonNull IdResolver idResolver = executor.getIdResolver();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine owningStateMachine = leafState.getOwningStateMachine();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull List<org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.State> nestedStates = leafState.getNestedStates();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull String name = leafState.getName();
		final /*@NonInvalid*/ @NonNull SetValue BOXED_nestedStates = idResolver.createSetOfAll(SET_CLSSid_State, nestedStates);
		final /*@NonInvalid*/ boolean isEmpty = CollectionIsEmptyOperation.INSTANCE.evaluate(BOXED_nestedStates).booleanValue();
		/*@Thrown*/ @Nullable Boolean symbol_5;
		if (isEmpty) {
			// creations
			final @SuppressWarnings("null")@NonNull TLeafState2FlatState trace_4 = PHierarchicalStateMachine2FlatStateMachineFactory.eINSTANCE.createTLeafState2FlatState();
			models[0/*middle*/].add(trace_4, false);
			// mapping statements
			OPPOSITE_OF_TLeafState2FlatState_leafState.put(leafState, trace_4);
			trace_4.setLeafState(leafState);
			trace_4.setStateName(name);
			trace_4.setHierarchicalStateMachine(owningStateMachine);
			jm_TLeafState2FlatState.appendElement(trace_4);
			final /*@Thrown*/ @Nullable Boolean m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0 = ValueUtil.TRUE_VALUE;
			symbol_5 = m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0;
		}
		else {
			symbol_5 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((symbol_5 ? "done "  : "fail ") + "MAP_m_TLeafState2FlatState_hierarchicalStateMachine_leaf_p0");
		}
		return symbol_5;
	}

	/**
	 *
	 * map m_THierachicalTransition2FlatTransition_flatStateMac_lc in HierarchicalStateMachine2FlatStateMachine {
	 * guard:middle trace  : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * var hierarchicalStateMachine : HierarchicalStateMachine::StateMachine[1] := trace.hierarchicalStateMachine;
	 * var leafFromState : HierarchicalStateMachine::State[1] := trace.leafFromState;
	 * var leafToState : HierarchicalStateMachine::State[1] := trace.leafToState;
	 * var transitionName : String[1] := trace.transitionName;
	 * var when_THierachicalStateMachine2FlatStateMachine : PHierarchicalStateMachine2FlatStateMachine::THierachicalStateMachine2FlatStateMachine[1] := hierarchicalStateMachine.THierachicalStateMachine2FlatStateMachine;
	 * var when_TLeafState2FlatState : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1] := leafFromState.TLeafState2FlatState;
	 * var when_TLeafState2FlatState_0 : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1] := leafToState.TLeafState2FlatState;
	 * var flatStateMachine : FlatStateMachine::StateMachine[1] := when_THierachicalStateMachine2FlatStateMachine.flatStateMachine;
	 * new:flat flatTransition : FlatStateMachine::Transition[1];
	 * set trace.flatTransition := flatTransition;
	 * set flatTransition.name := transitionName;
	 * set trace.flatStateMachine := flatStateMachine;
	 * set flatTransition.owningStateMachine := flatStateMachine;
	 *
	 */
	protected boolean MAP_m_THierachicalTransition2FlatTransition_flatStateMac_lc(final /*@NonInvalid*/ @NonNull THierachicalTransition2FlatTransition trace)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_THierachicalTransition2FlatTransition_flatStateMac_lc" + ", " + trace);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine hierarchicalStateMachine_0 = trace.getHierarchicalStateMachine();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafFromState_0 = trace.getLeafFromState();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafToState_0 = trace.getLeafToState();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull String transitionName = trace.getTransitionName();
		final /*@NonInvalid*/ @Nullable THierachicalStateMachine2FlatStateMachine THierachicalStateMachine2FlatStateMachine = OPPOSITE_OF_THierachicalStateMachine2FlatStateMachine_hierarchicalStateMachine.get(hierarchicalStateMachine_0);
		final /*@NonInvalid*/ boolean symbol_0 = THierachicalStateMachine2FlatStateMachine != null;
		/*@Thrown*/ @Nullable Boolean raw_when_THierachicalStateMachine2FlatStateMachine;
		if (symbol_0) {
			if (THierachicalStateMachine2FlatStateMachine == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			final /*@NonInvalid*/ @Nullable TLeafState2FlatState TLeafState2FlatState = OPPOSITE_OF_TLeafState2FlatState_leafState.get(leafFromState_0);
			final /*@NonInvalid*/ boolean symbol_1 = TLeafState2FlatState != null;
			/*@Thrown*/ @Nullable Boolean raw_when_TLeafState2FlatState;
			if (symbol_1) {
				if (TLeafState2FlatState == null) {
					throw new InvalidEvaluationException("Null where non-null value required");
				}
				final /*@NonInvalid*/ @Nullable TLeafState2FlatState TLeafState2FlatState_0 = OPPOSITE_OF_TLeafState2FlatState_leafState.get(leafToState_0);
				final /*@NonInvalid*/ boolean symbol_2 = TLeafState2FlatState_0 != null;
				/*@Thrown*/ @Nullable Boolean raw_when_TLeafState2FlatState_0;
				if (symbol_2) {
					if (TLeafState2FlatState_0 == null) {
						throw new InvalidEvaluationException("Null where non-null value required");
					}
					@SuppressWarnings("null")
					final /*@Thrown*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull StateMachine flatStateMachine = THierachicalStateMachine2FlatStateMachine.getFlatStateMachine();
					// creations
					final @SuppressWarnings("null")org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull Transition flatTransition = FlatStateMachineFactory.eINSTANCE.createTransition();
					models[2/*flat*/].add(flatTransition, false);
					// mapping statements
					trace.setFlatTransition(flatTransition);
					flatTransition.setName(transitionName);
					trace.setFlatStateMachine(flatStateMachine);
					flatTransition.setOwningStateMachine(flatStateMachine);
					final /*@Thrown*/ @Nullable Boolean m_THierachicalTransition2FlatTransition_flatStateMac_lc = ValueUtil.TRUE_VALUE;
					raw_when_TLeafState2FlatState_0 = m_THierachicalTransition2FlatTransition_flatStateMac_lc;
				}
				else {
					raw_when_TLeafState2FlatState_0 = ValueUtil.FALSE_VALUE;
				}
				raw_when_TLeafState2FlatState = raw_when_TLeafState2FlatState_0;
			}
			else {
				raw_when_TLeafState2FlatState = ValueUtil.FALSE_VALUE;
			}
			raw_when_THierachicalStateMachine2FlatStateMachine = raw_when_TLeafState2FlatState;
		}
		else {
			raw_when_THierachicalStateMachine2FlatStateMachine = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_when_THierachicalStateMachine2FlatStateMachine ? "done "  : "fail ") + "MAP_m_THierachicalTransition2FlatTransition_flatStateMac_lc");
		}
		return raw_when_THierachicalStateMachine2FlatStateMachine;
	}

	/**
	 *
	 * map m_TLeafState2FlatState_flatState_p1 in HierarchicalStateMachine2FlatStateMachine {
	 * guard:middle trace  : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * var hierarchicalStateMachine : HierarchicalStateMachine::StateMachine[1] := trace.hierarchicalStateMachine;
	 * var stateName : String[1] := trace.stateName;
	 * var when_THierachicalStateMachine2FlatStateMachine : PHierarchicalStateMachine2FlatStateMachine::THierachicalStateMachine2FlatStateMachine[1] := hierarchicalStateMachine.THierachicalStateMachine2FlatStateMachine;
	 * contained new:flat flatState : FlatStateMachine::State[1];
	 * set trace.flatState := flatState;
	 * set flatState.name := stateName;
	 *
	 */
	protected boolean MAP_m_TLeafState2FlatState_flatState_p1(final /*@NonInvalid*/ @NonNull TLeafState2FlatState trace_0)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_TLeafState2FlatState_flatState_p1" + ", " + trace_0);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine hierarchicalStateMachine_0 = trace_0.getHierarchicalStateMachine();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ @NonNull String stateName = trace_0.getStateName();
		final /*@NonInvalid*/ @Nullable THierachicalStateMachine2FlatStateMachine THierachicalStateMachine2FlatStateMachine = OPPOSITE_OF_THierachicalStateMachine2FlatStateMachine_hierarchicalStateMachine.get(hierarchicalStateMachine_0);
		final /*@NonInvalid*/ boolean symbol_0 = THierachicalStateMachine2FlatStateMachine != null;
		/*@Thrown*/ @Nullable Boolean raw_when_THierachicalStateMachine2FlatStateMachine;
		if (symbol_0) {
			if (THierachicalStateMachine2FlatStateMachine == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			// creations
			final @SuppressWarnings("null")org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull State flatState = FlatStateMachineFactory.eINSTANCE.createState();
			models[2/*flat*/].add(flatState, true);
			// mapping statements
			trace_0.setFlatState(flatState);
			flatState.setName(stateName);
			final /*@Thrown*/ @Nullable Boolean m_TLeafState2FlatState_flatState_p1 = ValueUtil.TRUE_VALUE;
			raw_when_THierachicalStateMachine2FlatStateMachine = m_TLeafState2FlatState_flatState_p1;
		}
		else {
			raw_when_THierachicalStateMachine2FlatStateMachine = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_when_THierachicalStateMachine2FlatStateMachine ? "done "  : "fail ") + "MAP_m_TLeafState2FlatState_flatState_p1");
		}
		return raw_when_THierachicalStateMachine2FlatStateMachine;
	}

	/**
	 *
	 * map m_THierachicalTransition2FlatTransition_flatFromStat_p2 in HierarchicalStateMachine2FlatStateMachine {
	 * guard:middle trace  : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * var flatTransition : FlatStateMachine::Transition[1] := trace.flatTransition;
	 * var leafFromState : HierarchicalStateMachine::State[1] := trace.leafFromState;
	 * var when_TLeafState2FlatState : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1] := leafFromState.TLeafState2FlatState;
	 * var flatFromState : FlatStateMachine::State[1] := when_TLeafState2FlatState.flatState;
	 * set flatTransition.fromState := flatFromState;
	 * set trace.flatFromState := flatFromState;
	 *
	 */
	protected boolean MAP_m_THierachicalTransition2FlatTransition_flatFromStat_p2(final /*@NonInvalid*/ @NonNull THierachicalTransition2FlatTransition trace_1)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_THierachicalTransition2FlatTransition_flatFromStat_p2" + ", " + trace_1);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull Transition flatTransition = trace_1.getFlatTransition();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafFromState_0 = trace_1.getLeafFromState();
		final /*@NonInvalid*/ @Nullable TLeafState2FlatState TLeafState2FlatState = OPPOSITE_OF_TLeafState2FlatState_leafState.get(leafFromState_0);
		final /*@NonInvalid*/ boolean symbol_0 = TLeafState2FlatState != null;
		/*@Thrown*/ @Nullable Boolean raw_when_TLeafState2FlatState;
		if (symbol_0) {
			if (TLeafState2FlatState == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@Thrown*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull State flatState = TLeafState2FlatState.getFlatState();
			// mapping statements
			flatTransition.setFromState(flatState);
			trace_1.setFlatFromState(flatState);
			final /*@Thrown*/ @Nullable Boolean m_THierachicalTransition2FlatTransition_flatFromStat_p2 = ValueUtil.TRUE_VALUE;
			raw_when_TLeafState2FlatState = m_THierachicalTransition2FlatTransition_flatFromStat_p2;
		}
		else {
			raw_when_TLeafState2FlatState = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_when_TLeafState2FlatState ? "done "  : "fail ") + "MAP_m_THierachicalTransition2FlatTransition_flatFromStat_p2");
		}
		return raw_when_TLeafState2FlatState;
	}

	/**
	 *
	 * map m_TLeafState2FlatState_flatStateMachine_p2 in HierarchicalStateMachine2FlatStateMachine {
	 * guard:middle trace  : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1];
	 * var flatState : FlatStateMachine::State[1] := trace.flatState;
	 * var hierarchicalStateMachine : HierarchicalStateMachine::StateMachine[1] := trace.hierarchicalStateMachine;
	 * var when_THierachicalStateMachine2FlatStateMachine : PHierarchicalStateMachine2FlatStateMachine::THierachicalStateMachine2FlatStateMachine[1] := hierarchicalStateMachine.THierachicalStateMachine2FlatStateMachine;
	 * var flatStateMachine : FlatStateMachine::StateMachine[1] := when_THierachicalStateMachine2FlatStateMachine.flatStateMachine;
	 * set trace.flatStateMachine := flatStateMachine;
	 * set flatState.owningStateMachine := flatStateMachine;
	 *
	 */
	protected boolean MAP_m_TLeafState2FlatState_flatStateMachine_p2(final /*@NonInvalid*/ @NonNull TLeafState2FlatState trace_2)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_TLeafState2FlatState_flatStateMachine_p2" + ", " + trace_2);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull State flatState = trace_2.getFlatState();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull StateMachine hierarchicalStateMachine_0 = trace_2.getHierarchicalStateMachine();
		final /*@NonInvalid*/ @Nullable THierachicalStateMachine2FlatStateMachine THierachicalStateMachine2FlatStateMachine = OPPOSITE_OF_THierachicalStateMachine2FlatStateMachine_hierarchicalStateMachine.get(hierarchicalStateMachine_0);
		final /*@NonInvalid*/ boolean symbol_0 = THierachicalStateMachine2FlatStateMachine != null;
		/*@Thrown*/ @Nullable Boolean raw_when_THierachicalStateMachine2FlatStateMachine;
		if (symbol_0) {
			if (THierachicalStateMachine2FlatStateMachine == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@Thrown*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull StateMachine flatStateMachine = THierachicalStateMachine2FlatStateMachine.getFlatStateMachine();
			// mapping statements
			trace_2.setFlatStateMachine(flatStateMachine);
			flatState.setOwningStateMachine(flatStateMachine);
			final /*@Thrown*/ @Nullable Boolean m_TLeafState2FlatState_flatStateMachine_p2 = ValueUtil.TRUE_VALUE;
			raw_when_THierachicalStateMachine2FlatStateMachine = m_TLeafState2FlatState_flatStateMachine_p2;
		}
		else {
			raw_when_THierachicalStateMachine2FlatStateMachine = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_when_THierachicalStateMachine2FlatStateMachine ? "done "  : "fail ") + "MAP_m_TLeafState2FlatState_flatStateMachine_p2");
		}
		return raw_when_THierachicalStateMachine2FlatStateMachine;
	}

	/**
	 *
	 * map m_THierachicalTransition2FlatTransition_flatToState_p4 in HierarchicalStateMachine2FlatStateMachine {
	 * guard:middle trace  : PHierarchicalStateMachine2FlatStateMachine::THierachicalTransition2FlatTransition[1];
	 * var flatTransition : FlatStateMachine::Transition[1] := trace.flatTransition;
	 * var leafToState : HierarchicalStateMachine::State[1] := trace.leafToState;
	 * var when_TLeafState2FlatState_0 : PHierarchicalStateMachine2FlatStateMachine::TLeafState2FlatState[1] := leafToState.TLeafState2FlatState;
	 * var flatToState : FlatStateMachine::State[1] := when_TLeafState2FlatState_0.flatState;
	 * set trace.flatToState := flatToState;
	 * set flatTransition.toState := flatToState;
	 *
	 */
	protected boolean MAP_m_THierachicalTransition2FlatTransition_flatToState_p4(final /*@NonInvalid*/ @NonNull THierachicalTransition2FlatTransition trace_3)  {
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println("invoke MAP_m_THierachicalTransition2FlatTransition_flatToState_p4" + ", " + trace_3);
		}
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull Transition flatTransition = trace_3.getFlatTransition();
		@SuppressWarnings("null")
		final /*@NonInvalid*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.HierarchicalStateMachine.@NonNull State leafToState_0 = trace_3.getLeafToState();
		final /*@NonInvalid*/ @Nullable TLeafState2FlatState TLeafState2FlatState = OPPOSITE_OF_TLeafState2FlatState_leafState.get(leafToState_0);
		final /*@NonInvalid*/ boolean symbol_0 = TLeafState2FlatState != null;
		/*@Thrown*/ @Nullable Boolean raw_when_TLeafState2FlatState_0;
		if (symbol_0) {
			if (TLeafState2FlatState == null) {
				throw new InvalidEvaluationException("Null where non-null value required");
			}
			@SuppressWarnings("null")
			final /*@Thrown*/ org.eclipse.qvtd.examples.qvtrelation.hstm2fstm.models.FlatStateMachine.@NonNull State flatState = TLeafState2FlatState.getFlatState();
			// mapping statements
			trace_3.setFlatToState(flatState);
			flatTransition.setToState(flatState);
			final /*@Thrown*/ @Nullable Boolean m_THierachicalTransition2FlatTransition_flatToState_p4 = ValueUtil.TRUE_VALUE;
			raw_when_TLeafState2FlatState_0 = m_THierachicalTransition2FlatTransition_flatToState_p4;
		}
		else {
			raw_when_TLeafState2FlatState_0 = ValueUtil.FALSE_VALUE;
		}
		if (debugInvocations) {
			AbstractTransformer.INVOCATIONS.println((raw_when_TLeafState2FlatState_0 ? "done "  : "fail ") + "MAP_m_THierachicalTransition2FlatTransition_flatToState_p4");
		}
		return raw_when_TLeafState2FlatState_0;
	}
}
